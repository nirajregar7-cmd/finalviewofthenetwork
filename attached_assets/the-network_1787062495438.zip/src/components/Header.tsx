import React, { useState } from 'react';
import { Search, Bell, X, Sparkles, Building, Hash, UserCheck } from 'lucide-react';
import { User, Community, Post } from '../types';

interface HeaderProps {
  currentUser: User;
  unreadNotificationsCount?: number;
  onOpenNotifications?: () => void;
  onOpenProfile: (user: User) => void;
  onSelectCommunity: (slug: string) => void;
  onSelectPost?: (post: Post) => void;
  onSelectTab?: (tab: any) => void;
  onMarkAllNotificationsRead?: () => void;
  communities: Community[];
  posts: Post[];
  users: Record<string, User>;
  notifications?: any[];
}

export const Header: React.FC<HeaderProps> = ({
  currentUser,
  unreadNotificationsCount = 0,
  onOpenNotifications,
  onOpenProfile,
  onSelectCommunity,
  onSelectPost,
  onSelectTab,
  onMarkAllNotificationsRead,
  communities,
  posts,
  users,
  notifications,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchFocused, setIsSearchFocused] = useState(false);

  // Filtered search items
  const matchingCommunities = searchQuery.trim()
    ? communities.filter(
        (c) =>
          c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          c.displayName.toLowerCase().includes(searchQuery.toLowerCase()) ||
          c.slug.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : [];

  const matchingUsers = searchQuery.trim()
    ? (Object.values(users) as User[]).filter(
        (u) =>
          u.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          u.college.toLowerCase().includes(searchQuery.toLowerCase()) ||
          u.skills.some((s) => s.toLowerCase().includes(searchQuery.toLowerCase()))
      )
    : [];

  const matchingPosts = searchQuery.trim()
    ? posts.filter(
        (p) =>
          p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          p.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
          p.tags?.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()))
      )
    : [];

  const hasResults =
    matchingCommunities.length > 0 || matchingUsers.length > 0 || matchingPosts.length > 0;

  return (
    <header className="top-nav sticky top-0 z-40 px-4 sm:px-8 flex items-center justify-between shadow-xs">
      <div className="w-full max-w-7xl mx-auto flex items-center justify-between gap-4">
        {/* Brand Logo - visible on mobile, minimal on desktop */}
        <div
          onClick={() => {
            onSelectTab?.('home');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className="flex items-center gap-2 cursor-pointer select-none shrink-0 group"
          id="brand-logo"
        >
          <div className="w-8 h-8 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-black text-sm shadow-sm shadow-indigo-200 lg:hidden">
            N
          </div>
          <div className="flex flex-col leading-none">
            <span className="text-base font-black tracking-tight text-slate-900 lg:hidden">
              THE NETWORK
            </span>
            <span className="hidden lg:inline text-xs font-bold text-slate-400 uppercase tracking-wider">
              Student Network
            </span>
          </div>
        </div>

        {/* Global Search Bar */}
        <div className="flex-1 max-w-xl relative">
          <div
            className={`search-bar flex items-center gap-2.5 px-4 py-2.5 transition-all duration-200 border ${
              isSearchFocused
                ? 'bg-white border-indigo-400 ring-2 ring-indigo-100 shadow-sm'
                : 'border-transparent hover:bg-slate-100/90'
            }`}
          >
            <Search className="w-4 h-4 text-slate-400 shrink-0" />
            <input
              type="text"
              id="global-search-input"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onFocus={() => setIsSearchFocused(true)}
              onBlur={() => setTimeout(() => setIsSearchFocused(false), 250)}
              placeholder="Search people, communities, colleges, topics..."
              className="w-full text-xs sm:text-sm text-slate-800 placeholder-slate-400 bg-transparent focus:outline-none"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="text-slate-400 hover:text-slate-600 p-0.5 cursor-pointer"
                aria-label="Clear search"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Autocomplete dropdown */}
          {isSearchFocused && searchQuery.trim().length > 0 && (
            <div className="absolute left-0 right-0 top-full mt-2 bg-white rounded-2xl border border-slate-100 shadow-xl overflow-hidden z-50 animate-in fade-in duration-150">
              {hasResults ? (
                <div className="max-h-96 overflow-y-auto p-2 space-y-3 divide-y divide-slate-50">
                  {/* Communities */}
                  {matchingCommunities.length > 0 && (
                    <div className="pt-1">
                      <div className="px-3 py-1 text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                        <Hash className="w-3 h-3 text-indigo-500" /> Communities
                      </div>
                      {matchingCommunities.slice(0, 3).map((comm) => (
                        <div
                          key={comm.id}
                          onClick={() => {
                            onSelectCommunity(comm.slug);
                            setSearchQuery('');
                          }}
                          className="flex items-center justify-between px-3 py-2 rounded-xl hover:bg-slate-50 cursor-pointer transition-colors"
                        >
                          <div className="flex items-center gap-2.5">
                            <span className="w-7 h-7 rounded-lg bg-indigo-50 text-indigo-600 font-mono font-bold text-xs flex items-center justify-center">
                              {comm.slug}
                            </span>
                            <div>
                              <p className="text-xs font-semibold text-slate-800">
                                {comm.slug}
                              </p>
                              <p className="text-[11px] text-slate-500 line-clamp-1">
                                {comm.displayName}
                              </p>
                            </div>
                          </div>
                          <span className="text-[11px] text-slate-400 font-medium">
                            {(comm.membersCount / 1000).toFixed(1)}k members
                          </span>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* People */}
                  {matchingUsers.length > 0 && (
                    <div className="pt-2">
                      <div className="px-3 py-1 text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                        <UserCheck className="w-3 h-3 text-emerald-500" /> Students & Mentors
                      </div>
                      {matchingUsers.slice(0, 3).map((u) => (
                        <div
                          key={u.id}
                          onClick={() => {
                            onOpenProfile(u);
                            setSearchQuery('');
                          }}
                          className="flex items-center justify-between px-3 py-2 rounded-xl hover:bg-slate-50 cursor-pointer transition-colors"
                        >
                          <div className="flex items-center gap-2.5">
                            <img
                              src={u.avatar}
                              alt={u.name}
                              className="w-7 h-7 rounded-full object-cover ring-1 ring-slate-100"
                            />
                            <div>
                              <div className="flex items-center gap-1">
                                <p className="text-xs font-semibold text-slate-800">
                                  {u.name}
                                </p>
                                {u.verified && (
                                  <span className="text-[10px] text-emerald-600 font-bold">
                                    ✓
                                  </span>
                                )}
                              </div>
                              <p className="text-[11px] text-slate-500">
                                {u.college} · {u.branch}
                              </p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Posts */}
                  {matchingPosts.length > 0 && (
                    <div className="pt-2">
                      <div className="px-3 py-1 text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                        <Sparkles className="w-3 h-3 text-amber-500" /> Discussions & Posts
                      </div>
                      {matchingPosts.slice(0, 3).map((p) => (
                        <div
                          key={p.id}
                          onClick={() => {
                            onSelectPost(p);
                            setSearchQuery('');
                          }}
                          className="px-3 py-2 rounded-xl hover:bg-slate-50 cursor-pointer transition-colors"
                        >
                          <p className="text-xs font-semibold text-slate-800 line-clamp-1">
                            {p.title}
                          </p>
                          <p className="text-[11px] text-slate-500">
                            in <span className="font-semibold text-indigo-600">{p.communitySlug}</span> by {p.author.name}
                          </p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ) : (
                <div className="p-6 text-center text-slate-400 text-xs">
                  No matching people, communities or discussions found for "{searchQuery}"
                </div>
              )}
            </div>
          )}
        </div>

        {/* Right Nav Icons */}
        <div className="flex items-center gap-3 shrink-0">
          {/* Notification Bell with Badge */}
          <button
            onClick={onOpenNotifications}
            id="header-notification-button"
            className="relative p-2 rounded-full hover:bg-slate-100 text-slate-600 hover:text-slate-900 transition-colors"
            title="Notifications"
            aria-label="Notifications"
          >
            <Bell className="w-5 h-5 text-slate-700" />
            {unreadNotificationsCount > 0 && (
              <span className="absolute 1 top-1 right-1 w-4 h-4 bg-rose-500 text-white font-bold text-[10px] rounded-full flex items-center justify-center shadow-sm">
                {unreadNotificationsCount}
              </span>
            )}
          </button>

          {/* User Profile Avatar with Online Status */}
          <button
            onClick={() => onOpenProfile(currentUser)}
            id="header-user-profile-button"
            className="relative flex items-center gap-2 p-0.5 rounded-full hover:ring-2 hover:ring-indigo-300 transition-all cursor-pointer"
            title="My Student Profile"
          >
            <img
              src={currentUser.avatar}
              alt={currentUser.name}
              className="w-9 h-9 rounded-full object-cover ring-2 ring-slate-100 shadow-sm"
            />
            <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-500 border-2 border-white rounded-full"></span>
          </button>
        </div>
      </div>
    </header>
  );
};
