import React from 'react';
import { Home, Users, UserPlus, BookOpen, MessageCircle, Plus } from 'lucide-react';
import { NavTab } from '../types';

interface BottomNavProps {
  currentTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  onOpenCreate: () => void;
  unreadChatsCount: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  currentTab,
  onSelectTab,
  onOpenCreate,
  unreadChatsCount,
}) => {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200/80 shadow-[0_-4px_12px_rgba(0,0,0,0.03)] py-1.5 px-4">
      <div className="max-w-lg mx-auto flex items-center justify-between relative">
        {/* Home */}
        <button
          onClick={() => onSelectTab('home')}
          id="nav-tab-home"
          className={`flex flex-col items-center justify-center w-14 py-1 gap-1 transition-colors cursor-pointer ${
            currentTab === 'home'
              ? 'text-indigo-600 font-bold'
              : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <Home className={`w-5 h-5 ${currentTab === 'home' ? 'stroke-[2.5]' : 'stroke-2'}`} />
          <span className="text-[11px] leading-tight">Home</span>
        </button>

        {/* Communities */}
        <button
          onClick={() => onSelectTab('communities')}
          id="nav-tab-communities"
          className={`flex flex-col items-center justify-center w-14 py-1 gap-1 transition-colors cursor-pointer ${
            currentTab === 'communities'
              ? 'text-indigo-600 font-bold'
              : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <Users className={`w-5 h-5 ${currentTab === 'communities' ? 'stroke-[2.5]' : 'stroke-2'}`} />
          <span className="text-[11px] leading-tight">Communities</span>
        </button>

        {/* Floating Center Create Button */}
        <div className="relative -top-5 flex flex-col items-center">
          <button
            onClick={onOpenCreate}
            id="floating-create-action-button"
            className="w-13 h-13 rounded-full bg-gradient-to-tr from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-600 text-white flex items-center justify-center shadow-lg shadow-indigo-500/30 hover:scale-105 active:scale-95 transition-all duration-200 cursor-pointer"
            aria-label="Create something new"
            title="Create Post, Question, Opportunity or Project"
          >
            <Plus className="w-7 h-7 stroke-[2.5]" />
          </button>
        </div>

        {/* Connect */}
        <button
          onClick={() => onSelectTab('connect')}
          id="nav-tab-connect"
          className={`flex flex-col items-center justify-center w-14 py-1 gap-1 transition-colors cursor-pointer ${
            currentTab === 'connect'
              ? 'text-indigo-600 font-bold'
              : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <UserPlus className={`w-5 h-5 ${currentTab === 'connect' ? 'stroke-[2.5]' : 'stroke-2'}`} />
          <span className="text-[11px] leading-tight">Connect</span>
        </button>

        {/* Learn */}
        <button
          onClick={() => onSelectTab('learn')}
          id="nav-tab-learn"
          className={`flex flex-col items-center justify-center w-14 py-1 gap-1 transition-colors cursor-pointer ${
            currentTab === 'learn'
              ? 'text-indigo-600 font-bold'
              : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <BookOpen className={`w-5 h-5 ${currentTab === 'learn' ? 'stroke-[2.5]' : 'stroke-2'}`} />
          <span className="text-[11px] leading-tight">Learn</span>
        </button>

        {/* Chats */}
        <button
          onClick={() => onSelectTab('chats')}
          id="nav-tab-chats"
          className={`flex flex-col items-center justify-center w-14 py-1 gap-1 relative transition-colors cursor-pointer ${
            currentTab === 'chats'
              ? 'text-indigo-600 font-bold'
              : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <div className="relative">
            <MessageCircle className={`w-5 h-5 ${currentTab === 'chats' ? 'stroke-[2.5]' : 'stroke-2'}`} />
            {unreadChatsCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-rose-500 text-white font-bold text-[9px] rounded-full flex items-center justify-center shadow-xs">
                {unreadChatsCount}
              </span>
            )}
          </div>
          <span className="text-[11px] leading-tight">Chats</span>
        </button>
      </div>
    </nav>
  );
};
