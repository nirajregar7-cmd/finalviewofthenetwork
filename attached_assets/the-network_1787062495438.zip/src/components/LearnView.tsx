import React, { useState } from 'react';
import {
  BookOpen,
  CheckCircle2,
  Lock,
  PlayCircle,
  FileText,
  HelpCircle,
  FolderGit2,
  Sparkles,
  ArrowRight,
  Clock,
  Bookmark,
  Users,
  Check,
  Award,
  ChevronRight
} from 'lucide-react';
import { LearningTopic, Opportunity, User } from '../types';
import confetti from 'canvas-confetti';

interface LearnViewProps {
  topic: LearningTopic;
  currentUser: User;
  onOpenProfile: (user: User) => void;
  onSelectCommunity: (slug: string) => void;
  onOpenOpportunity: (opp: Opportunity) => void;
  onOpenRecommendQuiz: () => void;
}

export const LearnView: React.FC<LearnViewProps> = ({
  topic,
  currentUser,
  onOpenProfile,
  onSelectCommunity,
  onOpenOpportunity,
  onOpenRecommendQuiz,
}) => {
  const [activeTab, setActiveTab] = useState<'for_you' | 'all' | 'roadmaps' | 'my_learning' | 'saved' | 'mentors'>('for_you');
  const [selectedStepId, setSelectedStepId] = useState<string>('step-2');
  const [steps, setSteps] = useState(topic.steps);

  const currentStep = steps.find((s) => s.id === selectedStepId) || steps[1];

  const handleToggleItem = (itemId: string) => {
    setSteps(
      steps.map((st) => {
        if (st.id === selectedStepId) {
          const updatedItems = st.items.map((it) => {
            if (it.id === itemId) {
              const nextStatus =
                it.status === 'completed'
                  ? 'in_progress'
                  : it.status === 'in_progress'
                  ? 'not_started'
                  : 'completed';
              if (nextStatus === 'completed') {
                confetti({ particleCount: 25, spread: 45 });
              }
              return { ...it, status: nextStatus as any };
            }
            return it;
          });
          return { ...st, items: updatedItems };
        }
        return st;
      })
    );
  };

  const completedCount = currentStep.items.filter((i) => i.status === 'completed').length;
  const totalCount = currentStep.items.length;
  const percent = Math.round((completedCount / totalCount) * 100);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-8 py-6 pb-28 space-y-6">
      {/* 1. Header */}
      <div>
        <h1 className="text-2xl font-black text-slate-900 tracking-tight">Learn</h1>
        <p className="text-xs sm:text-sm text-slate-500 font-medium">
          Learn together. Grow together.
        </p>
      </div>

      {/* 2. Nav Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-0.5">
        {(
          [
            { id: 'for_you', label: 'For you', icon: '✨' },
            { id: 'all', label: 'All Topics', icon: '⊞' },
            { id: 'roadmaps', label: 'Roadmaps', icon: '🗺️' },
            { id: 'my_learning', label: 'My Learning', icon: '📚' },
            { id: 'saved', label: 'Saved', icon: '🔖' },
            { id: 'mentors', label: 'Mentors', icon: '🎓' },
          ] as const
        ).map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-1.5 px-4 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all cursor-pointer border ${
              activeTab === tab.id
                ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
            }`}
          >
            <span>{tab.icon}</span>
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* 3. Hero / Continue Learning Card */}
      <div className="bg-gradient-to-r from-indigo-50/90 via-purple-50/50 to-white rounded-3xl border border-indigo-100 p-5 sm:p-6 relative overflow-hidden shadow-xs">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
          <div className="md:col-span-2 space-y-3">
            <div className="flex items-center gap-2 text-indigo-700">
              <span className="w-6 h-6 rounded-lg bg-indigo-100 flex items-center justify-center text-xs">
                🧠
              </span>
              <span className="text-xs font-bold uppercase tracking-wider">
                Continue learning
              </span>
            </div>

            <div>
              <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                {topic.name}
              </h2>
              <p className="text-xs text-slate-500 font-medium mt-0.5">
                {topic.summaryPath}
              </p>
            </div>

            {/* Progress bar */}
            <div className="space-y-1.5 max-w-md">
              <div className="flex items-center justify-between text-xs font-semibold text-slate-600">
                <span>Progress</span>
                <span>{topic.progressPercent}% completed</span>
              </div>
              <div className="w-full h-2.5 bg-slate-200/80 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-indigo-600 to-purple-600 rounded-full transition-all duration-500"
                  style={{ width: `${topic.progressPercent}%` }}
                ></div>
              </div>
            </div>

            {/* CTA Buttons */}
            <div className="flex items-center gap-3 pt-2">
              <button
                onClick={() => {
                  setSelectedStepId('step-2');
                  confetti({ particleCount: 20, spread: 40 });
                }}
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 active:scale-[0.98] text-white text-xs font-bold rounded-xl shadow-xs transition-all cursor-pointer"
              >
                Continue Roadmap
              </button>
              <button
                onClick={() => onSelectCommunity(topic.slug)}
                className="px-4 py-2 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 text-xs font-semibold rounded-xl transition-colors cursor-pointer"
              >
                View Roadmap
              </button>
            </div>
          </div>

          {/* 3D Stack of books & learning together counter */}
          <div className="flex flex-col items-center md:items-end justify-center space-y-3">
            <div className="w-28 h-28 rounded-2xl bg-gradient-to-tr from-indigo-100 to-purple-100 border border-indigo-200 flex items-center justify-center text-4xl shadow-inner relative">
              📚
              <span className="absolute -top-2 -right-2 text-2xl animate-bounce">🎓</span>
            </div>

            <div className="text-center md:text-right">
              <p className="text-xs font-bold text-slate-900">
                <span className="text-indigo-600 text-sm font-black">58</span> students
              </p>
              <p className="text-[11px] text-slate-500">learning together</p>
              <div className="flex -space-x-1.5 overflow-hidden justify-center md:justify-end mt-1">
                <img
                  className="inline-block h-5 w-5 rounded-full ring-2 ring-white object-cover"
                  src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&auto=format&fit=crop&q=80"
                  alt=""
                />
                <img
                  className="inline-block h-5 w-5 rounded-full ring-2 ring-white object-cover"
                  src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&auto=format&fit=crop&q=80"
                  alt=""
                />
                <img
                  className="inline-block h-5 w-5 rounded-full ring-2 ring-white object-cover"
                  src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&auto=format&fit=crop&q=80"
                  alt=""
                />
                <span className="h-5 w-5 rounded-full bg-slate-200 text-slate-600 text-[9px] font-bold flex items-center justify-center ring-2 ring-white">
                  +53
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 4. Popular Learning Topics */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-sm sm:text-base font-bold text-slate-900 tracking-tight">
            Popular learning topics
          </h2>
          <button className="text-xs font-semibold text-indigo-600 hover:text-indigo-700 cursor-pointer">
            View all
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 overflow-x-auto no-scrollbar">
          {(
            [
              { name: 'Data Structures & Algorithms', slug: '/dsa', students: '1.2K', icon: 'code', bg: 'bg-emerald-50 text-emerald-600 border-emerald-200' },
              { name: 'AI & Machine Learning', slug: '/ai-ml', students: '1.5K', icon: 'brain', bg: 'bg-pink-50 text-pink-600 border-pink-200' },
              { name: 'Web Development', slug: '/web-dev', students: '2.3K', icon: 'browser', bg: 'bg-sky-50 text-sky-600 border-sky-200' },
              { name: 'Operating Systems', slug: '/os', students: '842', icon: 'cpu', bg: 'bg-amber-50 text-amber-600 border-amber-200' },
              { name: 'Discrete Mathematics', slug: '/math', students: '684', icon: 'math', bg: 'bg-purple-50 text-purple-600 border-purple-200' },
            ] as const
          ).map((top) => (
            <div
              key={top.slug}
              onClick={() => onSelectCommunity(top.slug)}
              className="bg-white rounded-2xl border border-slate-200/80 p-3.5 flex flex-col justify-between space-y-2.5 hover:border-indigo-300 hover:shadow-xs transition-all cursor-pointer group"
            >
              <div className="space-y-2">
                <div className={`w-8 h-8 rounded-xl border flex items-center justify-center text-xs font-bold ${top.bg}`}>
                  {top.slug.slice(1, 3).toUpperCase()}
                </div>
                <div>
                  <h3 className="text-xs font-bold text-slate-900 group-hover:text-indigo-600 transition-colors leading-tight">
                    {top.name}
                  </h3>
                  <p className="text-[10px] text-slate-400 mt-0.5">{top.students} students</p>
                </div>
              </div>
              <div className="flex -space-x-1 overflow-hidden pt-1">
                <img className="h-4 w-4 rounded-full ring-1 ring-white" src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=50" alt="" />
                <img className="h-4 w-4 rounded-full ring-1 ring-white" src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=50" alt="" />
                <span className="h-4 w-4 rounded-full bg-slate-100 text-slate-500 text-[8px] font-bold flex items-center justify-center ring-1 ring-white">
                  +99
                </span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 5. Your Learning Roadmap (Stepper + Details + Resources) */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-sm sm:text-base font-bold text-slate-900 tracking-tight">
            Your learning roadmap
          </h2>
          <button
            onClick={() => onSelectCommunity(topic.slug)}
            className="text-xs font-semibold text-indigo-600 hover:text-indigo-700 cursor-pointer"
          >
            View all
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          {/* Left 4 Cols: Steps Stepper */}
          <div className="lg:col-span-4 bg-white rounded-2xl border border-slate-200/80 p-4 space-y-3">
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              Roadmap Modules
            </h3>
            <div className="space-y-2">
              {steps.map((st, idx) => {
                const isSelected = st.id === selectedStepId;
                return (
                  <div
                    key={st.id}
                    onClick={() => setSelectedStepId(st.id)}
                    className={`p-3 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
                      isSelected
                        ? 'bg-indigo-50/80 border-indigo-400 ring-2 ring-indigo-100 shadow-xs'
                        : 'bg-slate-50/50 border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-7 h-7 rounded-full flex items-center justify-center font-bold text-xs ${
                          st.status === 'completed'
                            ? 'bg-emerald-500 text-white'
                            : isSelected
                            ? 'bg-indigo-600 text-white'
                            : 'bg-slate-200 text-slate-600'
                        }`}
                      >
                        {st.status === 'completed' ? '✓' : idx + 1}
                      </div>
                      <div>
                        <h4 className="text-xs font-bold text-slate-900 leading-tight">
                          {st.title}
                        </h4>
                        <p className="text-[10px] text-slate-400 capitalize">
                          {st.status.replace('_', ' ')}
                        </p>
                      </div>
                    </div>

                    {st.status === 'locked' && (
                      <Lock className="w-3.5 h-3.5 text-slate-400" />
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Center 5 Cols: Active Step Checklist */}
          <div className="lg:col-span-5 bg-white rounded-2xl border border-slate-200/80 p-5 space-y-4">
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-black text-slate-900">{currentStep.title}</h3>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-50 text-indigo-700 capitalize">
                    {currentStep.status.replace('_', ' ')}
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-0.5 leading-relaxed">
                  {currentStep.description}
                </p>
              </div>
            </div>

            {/* Step progress */}
            <div className="space-y-1">
              <div className="flex items-center justify-between text-[11px] font-bold text-slate-600">
                <span>
                  {completedCount}/{totalCount} completed
                </span>
                <span>{percent}%</span>
              </div>
              <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
                <div
                  className="h-full bg-indigo-600 rounded-full transition-all duration-300"
                  style={{ width: `${percent}%` }}
                ></div>
              </div>
            </div>

            {/* Checklist Items */}
            <div className="space-y-2 pt-1">
              {currentStep.items.map((item, idx) => (
                <div
                  key={item.id}
                  onClick={() => handleToggleItem(item.id)}
                  className="flex items-center justify-between p-2.5 rounded-xl border border-slate-100 hover:border-indigo-200 hover:bg-slate-50/50 cursor-pointer transition-all group"
                >
                  <div className="flex items-center gap-2.5">
                    <div
                      className={`w-5 h-5 rounded-md flex items-center justify-center text-xs transition-colors ${
                        item.status === 'completed'
                          ? 'bg-emerald-500 text-white'
                          : 'border border-slate-300 group-hover:border-indigo-400'
                      }`}
                    >
                      {item.status === 'completed' && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                    </div>
                    <span
                      className={`text-xs font-semibold ${
                        item.status === 'completed'
                          ? 'text-slate-800 line-through text-opacity-60'
                          : 'text-slate-800'
                      }`}
                    >
                      {idx + 1}. {item.title}
                    </span>
                  </div>

                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full capitalize ${
                      item.status === 'completed'
                        ? 'text-emerald-700 bg-emerald-50'
                        : item.status === 'in_progress'
                        ? 'text-indigo-700 bg-indigo-50'
                        : 'text-slate-400 bg-slate-100'
                    }`}
                  >
                    {item.status.replace('_', ' ')}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Right 3 Cols: Resources for this step */}
          <div className="lg:col-span-3 bg-white rounded-2xl border border-slate-200/80 p-4 flex flex-col justify-between space-y-4">
            <div className="space-y-3">
              <h3 className="text-xs font-bold text-slate-900">Resources for this step</h3>
              <div className="space-y-2.5">
                <div className="flex items-center justify-between p-2 rounded-xl bg-slate-50">
                  <div className="flex items-center gap-2">
                    <FileText className="w-4 h-4 text-indigo-600" />
                    <span className="text-xs font-semibold text-slate-700">Notes</span>
                  </div>
                  <span className="text-[11px] font-bold text-slate-500">
                    {topic.resources.notesCount} resources
                  </span>
                </div>

                <div className="flex items-center justify-between p-2 rounded-xl bg-slate-50">
                  <div className="flex items-center gap-2">
                    <PlayCircle className="w-4 h-4 text-purple-600" />
                    <span className="text-xs font-semibold text-slate-700">Videos</span>
                  </div>
                  <span className="text-[11px] font-bold text-slate-500">
                    {topic.resources.videosCount} resources
                  </span>
                </div>

                <div className="flex items-center justify-between p-2 rounded-xl bg-slate-50">
                  <div className="flex items-center gap-2">
                    <HelpCircle className="w-4 h-4 text-emerald-600" />
                    <span className="text-xs font-semibold text-slate-700">Practice Problems</span>
                  </div>
                  <span className="text-[11px] font-bold text-slate-500">
                    {topic.resources.practiceCount} problems
                  </span>
                </div>

                <div className="flex items-center justify-between p-2 rounded-xl bg-slate-50">
                  <div className="flex items-center gap-2">
                    <FolderGit2 className="w-4 h-4 text-rose-600" />
                    <span className="text-xs font-semibold text-slate-700">Projects</span>
                  </div>
                  <span className="text-[11px] font-bold text-slate-500">
                    {topic.resources.projectsCount} projects
                  </span>
                </div>
              </div>
            </div>

            <button
              onClick={() => confetti({ particleCount: 20, spread: 40 })}
              className="w-full py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-xs font-bold rounded-xl transition-colors cursor-pointer"
            >
              Explore all resources
            </button>
          </div>
        </div>
      </section>

      {/* 6. Students Learning This & Opportunities Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Students Learning This */}
        <div className="bg-white rounded-2xl border border-slate-200/80 p-4 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-slate-900">Students learning this</h3>
            <button
              onClick={() => onSelectCommunity(topic.slug)}
              className="text-xs font-semibold text-indigo-600 hover:underline"
            >
              View all
            </button>
          </div>

          <div className="space-y-2">
            {(
              [
                { name: 'Aditi Deshmukh', college: 'NIT Trichy', branch: 'CSE', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100' },
                { name: 'Arjun Patel', college: 'IIT Madras', branch: 'EE', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100' },
                { name: 'Riya Sharma', college: 'NIT Surathkal', branch: 'ECE', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100' },
              ] as const
            ).map((st) => (
              <div key={st.name} className="flex items-center justify-between p-1.5 rounded-xl hover:bg-slate-50">
                <div className="flex items-center gap-2.5">
                  <img src={st.avatar} alt={st.name} className="w-8 h-8 rounded-full object-cover" />
                  <div>
                    <p className="text-xs font-bold text-slate-800">{st.name}</p>
                    <p className="text-[10px] text-slate-400">
                      {st.college} · {st.branch}
                    </p>
                  </div>
                </div>
                <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
              </div>
            ))}
          </div>

          <button
            onClick={() => onSelectCommunity(topic.slug)}
            className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-colors cursor-pointer"
          >
            Join the community
          </button>
        </div>

        {/* Opportunities For You */}
        <div className="bg-white rounded-2xl border border-slate-200/80 p-4 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-slate-900">Opportunities for you</h3>
            <span className="text-xs font-semibold text-indigo-600 hover:underline cursor-pointer">
              View all
            </span>
          </div>

          <div className="space-y-2.5">
            {topic.opportunities.map((opp) => (
              <div
                key={opp.id}
                onClick={() => onOpenOpportunity(opp)}
                className="flex items-center justify-between p-2 rounded-xl hover:bg-slate-50 cursor-pointer transition-colors"
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold text-xs">
                    {opp.category[0]}
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-800">{opp.title}</h4>
                    <p className="text-[10px] text-slate-500">{opp.prizeOrStipend}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2 text-[10px] font-bold text-slate-400">
                  <Clock className="w-3 h-3" />
                  <span>{opp.daysLeft} days left</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 7. Bottom Recommend Personalized Roadmap Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white rounded-3xl p-5 sm:p-6 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-md">
        <div>
          <h3 className="text-sm sm:text-base font-black">Not sure what to learn next?</h3>
          <p className="text-xs text-slate-300 mt-0.5">
            Answer a few questions and we'll suggest a personalized roadmap for your career goals.
          </p>
        </div>
        <button
          onClick={onOpenRecommendQuiz}
          className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 active:scale-[0.98] text-white text-xs font-bold rounded-xl shadow-lg shadow-indigo-600/30 flex items-center gap-1.5 shrink-0 transition-all cursor-pointer"
        >
          <Sparkles className="w-4 h-4" />
          <span>Recommend for me</span>
        </button>
      </div>
    </div>
  );
};
