import React, { useState } from 'react';
import {
  Search,
  Plus,
  Send,
  Paperclip,
  Smile,
  MoreVertical,
  CheckCheck,
  Check,
  Phone,
  Video,
  ChevronLeft,
  Users,
  Code,
  Sparkles,
  Image as ImageIcon
} from 'lucide-react';
import { ChatConversation, User } from '../types';
import confetti from 'canvas-confetti';

interface ChatsViewProps {
  conversations: ChatConversation[];
  currentUser: User;
  onOpenProfile: (user: User) => void;
  onSendMessage: (conversationId: string, text: string) => void;
}

export const ChatsView: React.FC<ChatsViewProps> = ({
  conversations,
  currentUser,
  onOpenProfile,
  onSendMessage,
}) => {
  const [activeTab, setActiveTab] = useState<'direct' | 'communities' | 'study_groups'>('direct');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedConversationId, setSelectedConversationId] = useState<string>(
    conversations[0]?.id || 'conv-1'
  );
  const [messageInput, setMessageInput] = useState('');
  const [showMobileThread, setShowMobileThread] = useState(false);

  const filteredConversations = conversations.filter((c) => {
    if (activeTab === 'direct' && c.type !== 'direct') return false;
    if (activeTab === 'communities' && c.type !== 'community') return false;
    if (activeTab === 'study_groups' && c.type !== 'study_group') return false;

    if (searchQuery.trim()) {
      const match =
        c.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.lastMessage.toLowerCase().includes(searchQuery.toLowerCase());
      if (!match) return false;
    }
    return true;
  });

  const activeConv = conversations.find((c) => c.id === selectedConversationId) || conversations[0];

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (messageInput.trim() && activeConv) {
      onSendMessage(activeConv.id, messageInput.trim());
      setMessageInput('');
      confetti({ particleCount: 15, spread: 30 });
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-8 py-6 pb-28">
      {/* Container Box */}
      <div className="bg-white rounded-3xl border border-slate-200/80 shadow-sm overflow-hidden h-[700px] flex flex-col md:flex-row">
        {/* LEFT COLUMN: Chat List */}
        <div
          className={`w-full md:w-80 lg:w-96 border-r border-slate-200/80 flex flex-col ${
            showMobileThread ? 'hidden md:flex' : 'flex'
          }`}
        >
          {/* Top Bar */}
          <div className="p-4 space-y-3 border-b border-slate-100">
            <div className="flex items-center justify-between">
              <h1 className="text-xl font-black text-slate-900 tracking-tight">Chats</h1>
              <button
                onClick={() => confetti({ particleCount: 20, spread: 40 })}
                className="p-1.5 rounded-full bg-indigo-50 text-indigo-600 hover:bg-indigo-100 transition-colors"
                title="New Chat"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>

            {/* Search */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search chats, people, groups..."
                className="w-full pl-8.5 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-indigo-400 focus:outline-none"
              />
            </div>

            {/* Tabs */}
            <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl">
              {(
                [
                  { id: 'direct', label: 'Direct' },
                  { id: 'communities', label: 'Communities' },
                  { id: 'study_groups', label: 'Study Groups' },
                ] as const
              ).map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex-1 py-1 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                    activeTab === tab.id
                      ? 'bg-white text-indigo-700 shadow-xs'
                      : 'text-slate-500 hover:text-slate-800'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {/* Conversation List */}
          <div className="flex-1 overflow-y-auto divide-y divide-slate-50">
            {filteredConversations.length > 0 ? (
              filteredConversations.map((conv) => {
                const isSelected = conv.id === activeConv?.id;
                return (
                  <div
                    key={conv.id}
                    onClick={() => {
                      setSelectedConversationId(conv.id);
                      setShowMobileThread(true);
                    }}
                    className={`p-3.5 flex items-center justify-between gap-3 cursor-pointer transition-colors ${
                      isSelected ? 'bg-indigo-50/70' : 'hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="relative shrink-0">
                        {conv.type === 'community' ? (
                          <div className="w-11 h-11 rounded-2xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-mono font-bold text-xs">
                            {conv.title.slice(1, 3).toUpperCase()}
                          </div>
                        ) : (
                          <img
                            src={conv.avatar}
                            alt={conv.title}
                            className="w-11 h-11 rounded-full object-cover ring-1 ring-slate-100"
                          />
                        )}
                        {conv.online && (
                          <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 rounded-full ring-2 ring-white"></span>
                        )}
                      </div>

                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5">
                          <h3 className="text-xs font-bold text-slate-900 truncate">
                            {conv.title}
                          </h3>
                          {conv.verified && (
                            <span className="w-3.5 h-3.5 rounded-full bg-emerald-100 text-emerald-700 text-[8px] font-bold flex items-center justify-center">
                              ✓
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-slate-500 truncate mt-0.5">
                          {conv.lastMessage}
                        </p>
                      </div>
                    </div>

                    <div className="text-right shrink-0">
                      <p className="text-[10px] font-medium text-slate-400">{conv.lastTimestamp}</p>
                      {conv.unreadCount > 0 && (
                        <span className="inline-flex items-center justify-center px-1.5 py-0.2 min-w-4 h-4 text-[10px] font-black text-white bg-indigo-600 rounded-full mt-1">
                          {conv.unreadCount}
                        </span>
                      )}
                    </div>
                  </div>
                );
              })
            ) : (
              <div className="p-6 text-center text-xs text-slate-400">
                No chats found in this category.
              </div>
            )}
          </div>
        </div>

        {/* RIGHT COLUMN: Active Chat Thread */}
        <div
          className={`flex-1 flex flex-col bg-slate-50/50 ${
            showMobileThread ? 'flex' : 'hidden md:flex'
          }`}
        >
          {activeConv ? (
            <>
              {/* Active Header */}
              <div className="p-3.5 px-5 bg-white border-b border-slate-200/80 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => setShowMobileThread(false)}
                    className="md:hidden text-slate-500 hover:text-slate-800 p-1 -ml-2"
                  >
                    <ChevronLeft className="w-5 h-5" />
                  </button>

                  <div className="relative">
                    {activeConv.type === 'community' ? (
                      <div className="w-10 h-10 rounded-2xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-mono font-bold text-xs">
                        {activeConv.title.slice(1, 3).toUpperCase()}
                      </div>
                    ) : (
                      <img
                        src={activeConv.avatar}
                        alt={activeConv.title}
                        className="w-10 h-10 rounded-full object-cover ring-1 ring-slate-100"
                      />
                    )}
                    {activeConv.online && (
                      <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-500 rounded-full ring-2 ring-white"></span>
                    )}
                  </div>

                  <div>
                    <div className="flex items-center gap-1.5">
                      <h2 className="text-xs sm:text-sm font-bold text-slate-900">
                        {activeConv.title}
                      </h2>
                      {activeConv.verified && (
                        <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-1.5 rounded-full">
                          ✓ Verified
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-slate-500">
                      {activeConv.subtitle || 'Active now'}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 text-slate-400">
                  <button
                    onClick={() => confetti({ particleCount: 20, spread: 35 })}
                    className="p-2 rounded-xl hover:bg-slate-100 hover:text-slate-700 transition-colors"
                    title="Audio call"
                  >
                    <Phone className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => confetti({ particleCount: 20, spread: 35 })}
                    className="p-2 rounded-xl hover:bg-slate-100 hover:text-slate-700 transition-colors"
                    title="Video call"
                  >
                    <Video className="w-4 h-4" />
                  </button>
                  <button className="p-2 rounded-xl hover:bg-slate-100 hover:text-slate-700 transition-colors">
                    <MoreVertical className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Messages Stream */}
              <div className="flex-1 p-4 sm:p-5 overflow-y-auto space-y-3.5">
                {/* Date separator */}
                <div className="flex items-center justify-center my-2">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 bg-white/80 px-3 py-1 rounded-full border border-slate-200/60 shadow-2xs">
                    Today
                  </span>
                </div>

                {activeConv.messages.map((msg) => {
                  const isMe = msg.senderId === currentUser.id;
                  return (
                    <div
                      key={msg.id}
                      className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
                    >
                      <div
                        className={`max-w-[78%] sm:max-w-md px-4 py-2.5 rounded-2xl text-xs sm:text-sm leading-relaxed shadow-2xs ${
                          isMe
                            ? 'bg-indigo-600 text-white rounded-br-xs'
                            : 'bg-white text-slate-800 border border-slate-200/80 rounded-bl-xs'
                        }`}
                      >
                        {!isMe && activeConv.type !== 'direct' && (
                          <p className="text-[10px] font-bold text-indigo-600 mb-0.5">
                            {msg.senderName}
                          </p>
                        )}
                        <p>{msg.text}</p>
                      </div>

                      <div className="flex items-center gap-1 text-[10px] text-slate-400 mt-1 px-1">
                        <span>{msg.timestamp}</span>
                        {isMe && (
                          <span>
                            <CheckCheck className="w-3.5 h-3.5 text-indigo-600 inline" />
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Message Composer Footer */}
              <form
                onSubmit={handleSend}
                className="p-3.5 bg-white border-t border-slate-200/80 flex items-center gap-2"
              >
                <button
                  type="button"
                  onClick={() => confetti({ particleCount: 10, spread: 20 })}
                  className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-xl"
                  title="Attach file"
                >
                  <Paperclip className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => confetti({ particleCount: 10, spread: 20 })}
                  className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-xl hidden sm:block"
                  title="Attach image"
                >
                  <ImageIcon className="w-4 h-4" />
                </button>

                <input
                  type="text"
                  value={messageInput}
                  onChange={(e) => setMessageInput(e.target.value)}
                  placeholder={`Message ${activeConv.title}...`}
                  className="flex-1 px-4 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-indigo-400 focus:outline-none"
                />

                <button
                  type="submit"
                  disabled={!messageInput.trim()}
                  className="p-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-40 text-white rounded-xl shadow-xs transition-all cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center text-slate-400 text-xs">
              Select a conversation to start chatting.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
