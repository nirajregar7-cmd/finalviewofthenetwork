import React, { useState } from 'react';
import {
  X,
  CheckCircle2,
  MapPin,
  Share2,
  Edit3,
  Users,
  Award,
  Sparkles,
  BookOpen,
  Github,
  Mail,
  GraduationCap,
  MessageCircle,
  Link,
  Code,
  Building,
  Target,
  FileText
} from 'lucide-react';
import { User } from '../types';
import confetti from 'canvas-confetti';

interface ProfileModalProps {
  user: User;
  currentUser: User;
  onClose: () => void;
  onSelectCommunity: (slug: string) => void;
  onToggleConnect: (userId: string) => void;
  onStartDirectChat: (user: User) => void;
  onUpdateCurrentUserProfile?: (updatedUser: Partial<User>) => void;
}

export const ProfileModal: React.FC<ProfileModalProps> = ({
  user,
  currentUser,
  onClose,
  onSelectCommunity,
  onToggleConnect,
  onStartDirectChat,
  onUpdateCurrentUserProfile,
}) => {
  const isMe = user.id === currentUser.id;
  const [isEditing, setIsEditing] = useState(false);
  const [editBio, setEditBio] = useState(user.bio);
  const [editCollege, setEditCollege] = useState(user.college);
  const [editBranch, setEditBranch] = useState(user.branch);

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (onUpdateCurrentUserProfile) {
      onUpdateCurrentUserProfile({
        bio: editBio,
        college: editCollege,
        branch: editBranch,
      });
    }
    setIsEditing(false);
    confetti({ particleCount: 30, spread: 50 });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto animate-in fade-in">
      <div className="bg-white rounded-3xl border border-slate-200 shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto relative my-8">
        {/* Top Floating Controls */}
        <div className="sticky top-0 bg-white/95 backdrop-blur-md px-6 py-3.5 border-b border-slate-100 flex items-center justify-between z-20">
          <div className="flex items-center gap-2">
            <span className="text-xs font-black uppercase tracking-wider text-slate-400">
              Student Profile
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                navigator.clipboard?.writeText(window.location.href);
                confetti({ particleCount: 20, spread: 35 });
              }}
              className="p-1.5 rounded-full hover:bg-slate-100 text-slate-500 transition-colors"
              title="Share profile"
            >
              <Share2 className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-full hover:bg-slate-100 text-slate-500 transition-colors"
              title="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Profile Content */}
        <div className="p-6 space-y-6">
          {/* Header Identity Section */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <img
                src={user.avatar}
                alt={user.name}
                className="w-20 h-20 rounded-2xl object-cover ring-4 ring-indigo-50 shadow-md"
              />
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <h1 className="text-xl font-black text-slate-900">{user.name}</h1>
                  {user.verified && (
                    <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                      ✓ Verified Student
                    </span>
                  )}
                </div>
                <p className="text-xs font-semibold text-slate-700 mt-0.5">{user.college}</p>
                <p className="text-xs text-slate-500">
                  {user.branch} · {user.year} · Class of 2026
                </p>
                <p className="text-[11px] text-slate-400 flex items-center gap-1 mt-1">
                  <MapPin className="w-3 h-3 text-slate-400" />
                  <span>{user.location || 'Tiruchirappalli, Tamil Nadu, India'}</span>
                </p>
              </div>
            </div>

            {/* Main Action CTAs */}
            <div className="flex items-center gap-2 w-full sm:w-auto">
              {isMe ? (
                <button
                  onClick={() => setIsEditing(!isEditing)}
                  className="w-full sm:w-auto px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl shadow-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>{isEditing ? 'Cancel Edit' : 'Edit Profile'}</span>
                </button>
              ) : (
                <>
                  <button
                    onClick={() => {
                      onToggleConnect(user.id);
                      if (!user.isConnected) confetti({ particleCount: 30, spread: 50 });
                    }}
                    className={`flex-1 sm:flex-none px-4 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
                      user.isConnected
                        ? 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                        : 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-xs'
                    }`}
                  >
                    {user.isConnected ? 'Connected ✓' : 'Connect'}
                  </button>
                  <button
                    onClick={() => {
                      onClose();
                      onStartDirectChat(user);
                    }}
                    className="p-2 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700 transition-colors"
                    title="Send message"
                  >
                    <MessageCircle className="w-4 h-4" />
                  </button>
                </>
              )}
            </div>
          </div>

          {/* Inline Edit Form */}
          {isEditing && (
            <form onSubmit={handleSaveEdit} className="p-4 bg-indigo-50/50 rounded-2xl border border-indigo-100 space-y-3">
              <h3 className="text-xs font-bold text-indigo-900">Edit Basic Details</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-bold text-slate-600">College Name</label>
                  <input
                    type="text"
                    value={editCollege}
                    onChange={(e) => setEditCollege(e.target.value)}
                    className="w-full text-xs p-2 rounded-lg border border-slate-200 bg-white"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-600">Branch</label>
                  <input
                    type="text"
                    value={editBranch}
                    onChange={(e) => setEditBranch(e.target.value)}
                    className="w-full text-xs p-2 rounded-lg border border-slate-200 bg-white"
                  />
                </div>
              </div>
              <div>
                <label className="text-[10px] font-bold text-slate-600">About / Bio</label>
                <textarea
                  value={editBio}
                  onChange={(e) => setEditBio(e.target.value)}
                  rows={2}
                  className="w-full text-xs p-2 rounded-lg border border-slate-200 bg-white"
                />
              </div>
              <button
                type="submit"
                className="px-4 py-1.5 bg-indigo-600 text-white text-xs font-bold rounded-lg hover:bg-indigo-700"
              >
                Save Changes
              </button>
            </form>
          )}

          {/* Quick Stats Ribbon */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 p-3 rounded-2xl bg-slate-50 border border-slate-100 text-center">
            <div>
              <p className="text-xs sm:text-sm font-black text-slate-900">
                {user.connectionsCount || 1240}
              </p>
              <p className="text-[10px] text-slate-400 font-medium">Connections</p>
            </div>
            <div>
              <p className="text-xs sm:text-sm font-black text-slate-900">
                {user.communities.length || 18}
              </p>
              <p className="text-[10px] text-slate-400 font-medium">Communities</p>
            </div>
            <div>
              <p className="text-xs sm:text-sm font-black text-slate-900">
                {user.projects?.length || 4}
              </p>
              <p className="text-[10px] text-slate-400 font-medium">Projects</p>
            </div>
            <div>
              <p className="text-xs sm:text-sm font-black text-indigo-600">1,840</p>
              <p className="text-[10px] text-slate-400 font-medium">Contribution Pts</p>
            </div>
          </div>

          {/* About Bio */}
          <div className="space-y-2">
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">About</h3>
            <p className="text-xs text-slate-600 leading-relaxed bg-white p-3.5 rounded-2xl border border-slate-100">
              {user.bio}
            </p>
          </div>

          {/* Goals & Target */}
          {user.goals && user.goals.length > 0 && (
            <div className="space-y-2">
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                Current Goals & Focus
              </h3>
              <div className="flex flex-wrap gap-2">
                {user.goals.map((g) => (
                  <span
                    key={g}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-indigo-50 text-indigo-700 border border-indigo-100"
                  >
                    <Target className="w-3.5 h-3.5" />
                    <span>{g}</span>
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Skills & Domains */}
          <div className="space-y-2">
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              Skills & Tech Stack
            </h3>
            <div className="flex flex-wrap gap-1.5">
              {user.skills.map((s) => (
                <span
                  key={s}
                  className="px-2.5 py-1 rounded-xl text-xs font-semibold bg-slate-100 text-slate-700 border border-slate-200/80"
                >
                  {s}
                </span>
              ))}
            </div>
          </div>

          {/* Available For */}
          {user.availableFor && user.availableFor.length > 0 && (
            <div className="space-y-2">
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                Available For
              </h3>
              <div className="space-y-1.5">
                {user.availableFor.map((item) => (
                  <div
                    key={item}
                    className="flex items-center gap-2 p-2.5 rounded-xl bg-emerald-50/50 border border-emerald-100 text-xs font-semibold text-emerald-800"
                  >
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Communities Joined */}
          <div className="space-y-2">
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              Communities Active In
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {user.communities.map((commSlug) => (
                <div
                  key={commSlug}
                  onClick={() => {
                    onClose();
                    onSelectCommunity(commSlug);
                  }}
                  className="p-2.5 rounded-xl border border-slate-200 hover:border-indigo-300 hover:bg-indigo-50/30 transition-all cursor-pointer flex items-center gap-2"
                >
                  <span className="w-7 h-7 rounded-lg bg-indigo-50 text-indigo-700 font-mono font-bold text-xs flex items-center justify-center">
                    {commSlug.slice(1, 3)}
                  </span>
                  <span className="text-xs font-bold text-slate-800 truncate">{commSlug}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Projects & Work */}
          {user.projects && user.projects.length > 0 && (
            <div className="space-y-2">
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                Projects & Work
              </h3>
              <div className="space-y-2.5">
                {user.projects.map((proj) => (
                  <div
                    key={proj.title}
                    className="p-3.5 rounded-2xl border border-slate-200/80 bg-slate-50/50 space-y-1.5"
                  >
                    <div className="flex items-center justify-between">
                      <h4 className="text-xs font-bold text-slate-900">{proj.title}</h4>
                      {proj.githubLink && (
                        <a
                          href={`https://${proj.githubLink}`}
                          target="_blank"
                          rel="noreferrer"
                          className="flex items-center gap-1 text-[11px] font-semibold text-indigo-600 hover:underline"
                        >
                          <Github className="w-3.5 h-3.5" />
                          <span>Code</span>
                        </a>
                      )}
                    </div>
                    <p className="text-xs text-slate-600">{proj.description}</p>
                    <div className="flex flex-wrap gap-1 pt-1">
                      {proj.tags.map((t) => (
                        <span
                          key={t}
                          className="px-2 py-0.5 rounded-md text-[10px] font-semibold bg-white border border-slate-200 text-slate-600"
                        >
                          {t}
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Verification Badge Details */}
          <div className="p-3.5 rounded-2xl bg-slate-900 text-white flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
                <GraduationCap className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs font-bold text-white">Institutional Identity Verified</p>
                <p className="text-[10px] text-slate-400">
                  Verified using edu institutional email · NIT Trichy
                </p>
              </div>
            </div>
            <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              Active
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
