import React, { useState } from 'react';
import {
  X,
  FileText,
  HelpCircle,
  FolderGit2,
  Trophy,
  Users,
  Paperclip,
  Sparkles,
  Building,
  Upload
} from 'lucide-react';
import { Community, User } from '../types';
import confetti from 'canvas-confetti';

interface CreatePostModalProps {
  communities: Community[];
  currentUser: User;
  onClose: () => void;
  onCreatePost: (postData: {
    communitySlug: string;
    type: 'post' | 'question' | 'project' | 'hackathon' | 'resource';
    title: string;
    content: string;
    prizePool?: string;
    teamSize?: string;
    deadline?: string;
    tags: string[];
    fileName?: string;
  }) => void;
  onCreateCommunity?: (communityData: {
    slug: string;
    displayName: string;
    description: string;
    category: 'college' | 'interest' | 'career';
  }) => void;
}

export const CreatePostModal: React.FC<CreatePostModalProps> = ({
  communities,
  currentUser,
  onClose,
  onCreatePost,
  onCreateCommunity,
}) => {
  const [modalMode, setModalMode] = useState<'post' | 'community'>('post');
  const [postType, setPostType] = useState<'post' | 'question' | 'project' | 'hackathon'>('post');
  const [communitySlug, setCommunitySlug] = useState(communities[0]?.slug || '/dsa');
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [tagsInput, setTagsInput] = useState('');
  const [prizePool, setPrizePool] = useState('₹1L prize pool');
  const [teamSize, setTeamSize] = useState('Teams of 4');
  const [deadline, setDeadline] = useState('5 days left');
  const [attachmentName, setAttachmentName] = useState<string | null>(null);

  // New community form
  const [newCommSlug, setNewCommSlug] = useState('');
  const [newCommTitle, setNewCommTitle] = useState('');
  const [newCommDesc, setNewCommDesc] = useState('');
  const [newCommCat, setNewCommCat] = useState<'college' | 'interest' | 'career'>('interest');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (modalMode === 'post') {
      if (!title.trim()) return;
      const tags = tagsInput
        .split(',')
        .map((t) => t.trim())
        .filter(Boolean);

      onCreatePost({
        communitySlug,
        type: postType,
        title: title.trim(),
        content: content.trim(),
        tags: tags.length > 0 ? tags : ['Discussion'],
        prizePool: postType === 'hackathon' ? prizePool : undefined,
        teamSize: postType === 'hackathon' ? teamSize : undefined,
        deadline: postType === 'hackathon' ? deadline : undefined,
        fileName: attachmentName || undefined,
      });
      confetti({ particleCount: 40, spread: 60 });
      onClose();
    } else {
      if (!newCommSlug.trim() || !newCommTitle.trim()) return;
      const formattedSlug = newCommSlug.startsWith('/') ? newCommSlug : `/${newCommSlug}`;
      if (onCreateCommunity) {
        onCreateCommunity({
          slug: formattedSlug,
          displayName: newCommTitle,
          description: newCommDesc || 'A student community for discussions & learning',
          category: newCommCat,
        });
      }
      confetti({ particleCount: 50, spread: 70 });
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto animate-in fade-in">
      <div className="bg-white rounded-3xl border border-slate-200 shadow-2xl max-w-xl w-full overflow-hidden relative my-8">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl">
            <button
              onClick={() => setModalMode('post')}
              className={`px-3 py-1 text-xs font-bold rounded-lg transition-all ${
                modalMode === 'post' ? 'bg-white text-indigo-700 shadow-xs' : 'text-slate-500'
              }`}
            >
              Create Post / Doubt
            </button>
            <button
              onClick={() => setModalMode('community')}
              className={`px-3 py-1 text-xs font-bold rounded-lg transition-all ${
                modalMode === 'community' ? 'bg-white text-indigo-700 shadow-xs' : 'text-slate-500'
              }`}
            >
              New Community
            </button>
          </div>
          <button onClick={onClose} className="p-1 rounded-full text-slate-400 hover:text-slate-700">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {modalMode === 'post' ? (
            <>
              {/* Type pills */}
              <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
                {(
                  [
                    { id: 'post', label: '📝 Post' },
                    { id: 'question', label: '❓ Question / Doubt' },
                    { id: 'project', label: '💻 Project' },
                    { id: 'hackathon', label: '🚀 Hackathon' },
                  ] as const
                ).map((t) => (
                  <button
                    key={t.id}
                    type="button"
                    onClick={() => setPostType(t.id)}
                    className={`px-3 py-1 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
                      postType === t.id
                        ? 'bg-indigo-600 text-white shadow-xs'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {t.label}
                  </button>
                ))}
              </div>

              {/* Select Community */}
              <div>
                <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider block mb-1">
                  Post to Community
                </label>
                <select
                  value={communitySlug}
                  onChange={(e) => setCommunitySlug(e.target.value)}
                  className="w-full text-xs font-semibold p-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:border-indigo-400 focus:outline-none"
                >
                  {communities.map((c) => (
                    <option key={c.id} value={c.slug}>
                      {c.slug} — {c.displayName}
                    </option>
                  ))}
                </select>
              </div>

              {/* Title */}
              <div>
                <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider block mb-1">
                  Title
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder={
                    postType === 'question'
                      ? 'e.g. How should I prepare for GATE EE signals?'
                      : 'e.g. Built a modern DSA visualizer for graph traversal'
                  }
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:border-indigo-400 focus:outline-none"
                />
              </div>

              {/* Content */}
              <div>
                <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider block mb-1">
                  Description / Details
                </label>
                <textarea
                  rows={4}
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="Share code, background context, or problem details..."
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:border-indigo-400 focus:outline-none"
                />
              </div>

              {/* Special Hackathon Fields */}
              {postType === 'hackathon' && (
                <div className="grid grid-cols-3 gap-2 p-3 bg-purple-50 rounded-xl border border-purple-100">
                  <div>
                    <label className="text-[10px] font-bold text-purple-900">Prize Pool</label>
                    <input
                      type="text"
                      value={prizePool}
                      onChange={(e) => setPrizePool(e.target.value)}
                      className="w-full text-xs p-1.5 rounded-lg border border-purple-200 bg-white"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-purple-900">Team Size</label>
                    <input
                      type="text"
                      value={teamSize}
                      onChange={(e) => setTeamSize(e.target.value)}
                      className="w-full text-xs p-1.5 rounded-lg border border-purple-200 bg-white"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-purple-900">Deadline</label>
                    <input
                      type="text"
                      value={deadline}
                      onChange={(e) => setDeadline(e.target.value)}
                      className="w-full text-xs p-1.5 rounded-lg border border-purple-200 bg-white"
                    />
                  </div>
                </div>
              )}

              {/* Attachment simulator */}
              <div className="flex items-center justify-between p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                <div className="flex items-center gap-2">
                  <Upload className="w-4 h-4 text-slate-500" />
                  <span className="text-xs text-slate-600">
                    {attachmentName ? attachmentName : 'Attach PDF notes or cheat-sheet'}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setAttachmentName('Algorithm_Roadmap_Niraj.pdf (1.4 MB)')}
                  className="px-2.5 py-1 text-xs font-semibold text-indigo-600 bg-indigo-50 hover:bg-indigo-100 rounded-lg"
                >
                  {attachmentName ? 'Uploaded ✓' : 'Add Sample PDF'}
                </button>
              </div>

              {/* Tags */}
              <div>
                <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider block mb-1">
                  Tags (comma separated)
                </label>
                <input
                  type="text"
                  value={tagsInput}
                  onChange={(e) => setTagsInput(e.target.value)}
                  placeholder="e.g. Beginners, DSA Roadmap, Python"
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:border-indigo-400 focus:outline-none"
                />
              </div>
            </>
          ) : (
            /* Create Community Mode */
            <>
              <div>
                <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider block mb-1">
                  Community Handle (Slug)
                </label>
                <input
                  type="text"
                  required
                  value={newCommSlug}
                  onChange={(e) => setNewCommSlug(e.target.value)}
                  placeholder="e.g. /rust-lang or /quantum-computing"
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-200 bg-slate-50 font-mono focus:bg-white focus:border-indigo-400 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider block mb-1">
                  Display Name
                </label>
                <input
                  type="text"
                  required
                  value={newCommTitle}
                  onChange={(e) => setNewCommTitle(e.target.value)}
                  placeholder="e.g. Rust Programming & Systems"
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:border-indigo-400 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider block mb-1">
                  Category
                </label>
                <select
                  value={newCommCat}
                  onChange={(e) => setNewCommCat(e.target.value as any)}
                  className="w-full text-xs font-semibold p-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:border-indigo-400 focus:outline-none"
                >
                  <option value="interest">Interest / Technology</option>
                  <option value="career">Career / Exam (GATE, JEE, Placements)</option>
                  <option value="college">College / University</option>
                </select>
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider block mb-1">
                  Purpose / Description
                </label>
                <textarea
                  rows={3}
                  value={newCommDesc}
                  onChange={(e) => setNewCommDesc(e.target.value)}
                  placeholder="What is this community about? What should students share here?"
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:border-indigo-400 focus:outline-none"
                />
              </div>
            </>
          )}

          {/* Submit */}
          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-500 hover:bg-slate-100 rounded-xl"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl shadow-xs transition-all cursor-pointer"
            >
              {modalMode === 'post' ? 'Publish Post' : 'Create Community'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
