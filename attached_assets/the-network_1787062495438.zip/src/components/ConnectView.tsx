import React, { useState } from 'react';
import {
  Search,
  Users,
  Building,
  GraduationCap,
  Sparkles,
  SlidersHorizontal,
  Check,
  Star,
  MessageCircle,
  Calendar,
  Award,
  ChevronDown
} from 'lucide-react';
import { Community, User } from '../types';
import confetti from 'canvas-confetti';

interface ConnectViewProps {
  users: Record<string, User>;
  communities: Community[];
  currentUser: User;
  onOpenProfile: (user: User) => void;
  onSelectCommunity: (slug: string) => void;
  onToggleConnect: (userId: string) => void;
  onToggleJoinCommunity: (slug: string) => void;
  onBookMentor: (mentor: User) => void;
  onStartDirectChat: (user: User) => void;
}

export const ConnectView: React.FC<ConnectViewProps> = ({
  users,
  communities,
  currentUser,
  onOpenProfile,
  onSelectCommunity,
  onToggleConnect,
  onToggleJoinCommunity,
  onBookMentor,
  onStartDirectChat,
}) => {
  const [activeCategoryFilter, setActiveCategoryFilter] = useState<'all' | 'students' | 'communities' | 'mentors'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [collegeFilter, setCollegeFilter] = useState('All');
  const [branchFilter, setBranchFilter] = useState('All');
  const [skillFilter, setSkillFilter] = useState('All');

  // Filter students
  const studentList = (Object.values(users) as User[]).filter((u) => {
    if (u.id === currentUser.id) return false;
    if (u.mentorInfo?.isMentor && activeCategoryFilter === 'students') return false;

    // Search query
    if (searchQuery.trim()) {
      const matchText =
        u.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        u.college.toLowerCase().includes(searchQuery.toLowerCase()) ||
        u.branch.toLowerCase().includes(searchQuery.toLowerCase()) ||
        u.skills.some((s) => s.toLowerCase().includes(searchQuery.toLowerCase()));
      if (!matchText) return false;
    }

    if (collegeFilter !== 'All' && !u.college.includes(collegeFilter)) return false;
    if (branchFilter !== 'All' && !u.branch.includes(branchFilter)) return false;
    if (skillFilter !== 'All' && !u.skills.includes(skillFilter)) return false;

    return true;
  });

  const mentorsList = (Object.values(users) as User[]).filter((u) => u.mentorInfo?.isMentor);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-8 py-6 pb-28 space-y-6">
      {/* 1. Page Header */}
      <div>
        <h1 className="text-2xl font-black text-slate-900 tracking-tight">Connect</h1>
        <p className="text-xs sm:text-sm text-slate-500 font-medium">
          Find the right people, communities and mentors.
        </p>
      </div>

      {/* 2. Top 3 Category Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {/* Students card */}
        <div
          onClick={() => setActiveCategoryFilter('students')}
          className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-center gap-3.5 ${
            activeCategoryFilter === 'students'
              ? 'bg-indigo-50/80 border-indigo-300 ring-2 ring-indigo-100 shadow-xs'
              : 'bg-white border-slate-200 hover:border-indigo-200'
          }`}
        >
          <div className="w-11 h-11 rounded-2xl bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold">
            <Users className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-xs sm:text-sm font-bold text-slate-900">Students</h3>
            <p className="text-[11px] text-slate-500 leading-tight">
              Find and connect with students like you
            </p>
          </div>
        </div>

        {/* Communities card */}
        <div
          onClick={() => setActiveCategoryFilter('communities')}
          className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-center gap-3.5 ${
            activeCategoryFilter === 'communities'
              ? 'bg-emerald-50/80 border-emerald-300 ring-2 ring-emerald-100 shadow-xs'
              : 'bg-white border-slate-200 hover:border-emerald-200'
          }`}
        >
          <div className="w-11 h-11 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">
            <Building className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-xs sm:text-sm font-bold text-slate-900">Communities</h3>
            <p className="text-[11px] text-slate-500 leading-tight">
              Join colleges, clubs and interest communities
            </p>
          </div>
        </div>

        {/* Mentors card */}
        <div
          onClick={() => setActiveCategoryFilter('mentors')}
          className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-center gap-3.5 ${
            activeCategoryFilter === 'mentors'
              ? 'bg-amber-50/80 border-amber-300 ring-2 ring-amber-100 shadow-xs'
              : 'bg-white border-slate-200 hover:border-amber-200'
          }`}
        >
          <div className="w-11 h-11 rounded-2xl bg-amber-100 text-amber-700 flex items-center justify-center font-bold">
            <GraduationCap className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-xs sm:text-sm font-bold text-slate-900">Mentors</h3>
            <p className="text-[11px] text-slate-500 leading-tight">
              Learn from seniors who can guide you
            </p>
          </div>
        </div>
      </div>

      {/* 3. Students Section */}
      {(activeCategoryFilter === 'all' || activeCategoryFilter === 'students') && (
        <section className="bg-white rounded-3xl border border-slate-200/80 p-4 sm:p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center">
                <Users className="w-3.5 h-3.5" />
              </div>
              <div>
                <h2 className="text-sm sm:text-base font-bold text-slate-900">Students</h2>
                <p className="text-[11px] text-slate-400">Connect with students based on your filters.</p>
              </div>
            </div>
            <button
              onClick={() => {
                setCollegeFilter('All');
                setBranchFilter('All');
                setSkillFilter('All');
                setSearchQuery('');
              }}
              className="text-xs font-semibold text-indigo-600 hover:text-indigo-700"
            >
              Reset filters
            </button>
          </div>

          {/* Filter Toolbar */}
          <div className="flex flex-wrap items-center gap-2 pt-1 pb-2">
            <div className="flex-1 min-w-[200px] relative">
              <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search by name, college, branch, skills..."
                className="w-full pl-8.5 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-indigo-400 focus:outline-none"
              />
            </div>

            {/* College dropdown */}
            <select
              value={collegeFilter}
              onChange={(e) => setCollegeFilter(e.target.value)}
              className="px-2.5 py-1.5 text-xs font-medium bg-slate-50 border border-slate-200 rounded-xl focus:outline-none text-slate-700"
            >
              <option value="All">College: All</option>
              <option value="NIT Trichy">NIT Trichy</option>
              <option value="IIT Madras">IIT Madras</option>
              <option value="IIT Roorkee">IIT Roorkee</option>
              <option value="IIT Indore">IIT Indore</option>
              <option value="NIT Surathkal">NIT Surathkal</option>
            </select>

            {/* Branch dropdown */}
            <select
              value={branchFilter}
              onChange={(e) => setBranchFilter(e.target.value)}
              className="px-2.5 py-1.5 text-xs font-medium bg-slate-50 border border-slate-200 rounded-xl focus:outline-none text-slate-700"
            >
              <option value="All">Branch: All</option>
              <option value="Computer Science">Computer Science / CSE</option>
              <option value="Electrical">Electrical / EE</option>
              <option value="Mechanical">Mechanical Engineering</option>
            </select>

            {/* Skill dropdown */}
            <select
              value={skillFilter}
              onChange={(e) => setSkillFilter(e.target.value)}
              className="px-2.5 py-1.5 text-xs font-medium bg-slate-50 border border-slate-200 rounded-xl focus:outline-none text-slate-700"
            >
              <option value="All">Skills: All</option>
              <option value="DSA">DSA</option>
              <option value="Web Development">Web Development</option>
              <option value="Python">Python</option>
              <option value="System Design">System Design</option>
              <option value="GATE">GATE</option>
            </select>
          </div>

          {/* Student Cards List */}
          <div className="space-y-3">
            {studentList.map((student) => (
              <div
                key={student.id}
                className="p-3.5 sm:p-4 rounded-2xl border border-slate-100 bg-slate-50/50 hover:bg-white hover:border-indigo-200 hover:shadow-xs transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3"
              >
                {/* Info */}
                <div className="flex items-center gap-3.5">
                  <img
                    src={student.avatar}
                    alt={student.name}
                    onClick={() => onOpenProfile(student)}
                    className="w-12 h-12 rounded-full object-cover ring-2 ring-white shadow-xs cursor-pointer hover:opacity-90"
                  />
                  <div>
                    <div className="flex items-center gap-1.5">
                      <h3
                        onClick={() => onOpenProfile(student)}
                        className="text-xs sm:text-sm font-bold text-slate-900 hover:text-indigo-600 cursor-pointer"
                      >
                        {student.name}
                      </h3>
                      {student.verified && (
                        <span className="w-4 h-4 rounded-full bg-emerald-100 text-emerald-700 text-[10px] font-bold flex items-center justify-center">
                          ✓
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-slate-500">
                      {student.college} · {student.branch}
                    </p>

                    {/* Skill Badges */}
                    <div className="flex flex-wrap items-center gap-1 mt-1.5">
                      {student.skills.slice(0, 3).map((sk) => (
                        <span
                          key={sk}
                          className="px-2 py-0.5 rounded-md text-[10px] font-semibold bg-white border border-slate-200 text-slate-700"
                        >
                          {sk}
                        </span>
                      ))}
                      {student.skills.length > 3 && (
                        <span className="text-[10px] text-slate-400 font-medium">
                          +{student.skills.length - 3}
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Match Score & Connect CTA */}
                <div className="flex items-center justify-between sm:justify-end gap-3.5 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-200/60">
                  <div className="text-left sm:text-right">
                    <p className="text-xs font-bold text-emerald-600">
                      {student.matchScore || 85}% match
                    </p>
                    <p className="text-[10px] text-slate-400">
                      {student.mutualCommunitiesCount || 15} mutual communities
                    </p>
                    <div className="flex items-center gap-1 justify-start sm:justify-end mt-1">
                      <span className="text-[10px] px-1 py-0.2 rounded bg-emerald-50 text-emerald-700 border border-emerald-200 font-mono">
                        &lt;/&gt;
                      </span>
                      <span className="text-[10px] px-1 py-0.2 rounded bg-pink-50 text-pink-700 border border-pink-200">
                        🧠
                      </span>
                      <span className="text-[10px] px-1 py-0.2 rounded bg-purple-50 text-purple-700 border border-purple-200">
                        🏛️
                      </span>
                      <span className="text-[9px] text-slate-400 font-bold">+12</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => onStartDirectChat(student)}
                      className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors"
                      title="Direct Chat"
                    >
                      <MessageCircle className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => {
                        onToggleConnect(student.id);
                        if (!student.isConnected) {
                          confetti({ particleCount: 30, spread: 50 });
                        }
                      }}
                      className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                        student.isConnected
                          ? 'bg-slate-200 text-slate-700'
                          : 'bg-white border border-indigo-600 text-indigo-600 hover:bg-indigo-50 shadow-xs'
                      }`}
                    >
                      {student.isConnected ? 'Connected ✓' : 'Connect'}
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center pt-1">
            <button className="text-xs font-bold text-indigo-600 hover:text-indigo-700 inline-flex items-center gap-1">
              Show more students <ChevronDown className="w-3.5 h-3.5" />
            </button>
          </div>
        </section>
      )}

      {/* 4. Communities Section */}
      {(activeCategoryFilter === 'all' || activeCategoryFilter === 'communities') && (
        <section className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center">
                <Building className="w-3.5 h-3.5" />
              </div>
              <h2 className="text-sm sm:text-base font-bold text-slate-900">Communities</h2>
            </div>
            <button
              onClick={() => setActiveCategoryFilter('communities')}
              className="text-xs font-semibold text-indigo-600 hover:text-indigo-700"
            >
              View all
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
            {communities.slice(0, 5).map((comm) => (
              <div
                key={comm.id}
                className="bg-white rounded-2xl border border-slate-200/80 p-3.5 flex flex-col justify-between space-y-3 hover:border-indigo-300 transition-all"
              >
                <div
                  onClick={() => onSelectCommunity(comm.slug)}
                  className="space-y-1.5 cursor-pointer"
                >
                  <div
                    className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold text-sm ${comm.iconBg}`}
                  >
                    {comm.slug.slice(1, 3).toUpperCase()}
                  </div>
                  <h3 className="text-xs font-bold text-slate-900">{comm.slug}</h3>
                  <p className="text-[10px] text-slate-500">
                    {(comm.membersCount / 1000).toFixed(1)}K members
                  </p>
                </div>
                <button
                  onClick={() => onToggleJoinCommunity(comm.slug)}
                  className={`w-full py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    comm.isJoined
                      ? 'bg-slate-100 text-indigo-700 border border-slate-200'
                      : 'bg-indigo-600 hover:bg-indigo-700 text-white'
                  }`}
                >
                  {comm.isJoined ? 'Joined' : 'Join'}
                </button>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* 5. Top Mentors Section */}
      {(activeCategoryFilter === 'all' || activeCategoryFilter === 'mentors') && (
        <section className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center">
                <GraduationCap className="w-3.5 h-3.5" />
              </div>
              <h2 className="text-sm sm:text-base font-bold text-slate-900">Top Mentors</h2>
            </div>
            <button
              onClick={() => setActiveCategoryFilter('mentors')}
              className="text-xs font-semibold text-indigo-600 hover:text-indigo-700"
            >
              View all
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
            {mentorsList.map((mentor) => (
              <div
                key={mentor.id}
                className="bg-white rounded-2xl border border-slate-200/80 p-4 flex flex-col justify-between space-y-3.5 shadow-xs hover:border-amber-200 transition-all"
              >
                <div className="space-y-2.5">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <img
                        src={mentor.avatar}
                        alt={mentor.name}
                        onClick={() => onOpenProfile(mentor)}
                        className="w-11 h-11 rounded-full object-cover ring-1 ring-slate-100 cursor-pointer"
                      />
                      <div>
                        <h3
                          onClick={() => onOpenProfile(mentor)}
                          className="text-xs font-bold text-slate-900 hover:text-indigo-600 cursor-pointer"
                        >
                          {mentor.name}
                        </h3>
                        <p className="text-[10px] text-slate-500">{mentor.college}</p>
                        <div className="flex items-center gap-1 text-[10px] text-amber-600 font-semibold mt-0.5">
                          <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                          <span>{mentor.mentorInfo?.rating}</span>
                          <span className="text-slate-400">· {mentor.mentorInfo?.studentsHelped} helped</span>
                        </div>
                      </div>
                    </div>
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        mentor.mentorInfo?.price === 'Free'
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          : 'bg-amber-50 text-amber-700 border border-amber-200'
                      }`}
                    >
                      {mentor.mentorInfo?.price}
                    </span>
                  </div>

                  <div>
                    <p className="text-xs font-bold text-slate-800 leading-tight">
                      {mentor.mentorInfo?.speciality}
                    </p>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      {mentor.mentorInfo?.companyOrRole}
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => onBookMentor(mentor)}
                  className="w-full py-2 bg-white border border-indigo-600 hover:bg-indigo-50 active:scale-[0.98] text-indigo-600 text-xs font-bold rounded-xl transition-all cursor-pointer"
                >
                  Book / Connect
                </button>
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
};
