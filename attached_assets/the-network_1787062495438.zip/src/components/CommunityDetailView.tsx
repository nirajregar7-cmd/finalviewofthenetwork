import React, { useState } from 'react';
import {
  ArrowLeft,
  Bell,
  Code,
  Check,
  Plus,
  Share2,
  Bookmark,
  MoreVertical,
  ArrowUp,
  ArrowDown,
  MessageSquare,
  FileText,
  Github,
  Award,
  Sparkles,
  SlidersHorizontal,
  Send,
  Users,
  ShieldCheck,
  BookOpen,
  HelpCircle,
  FolderGit2,
  BarChart2
} from 'lucide-react';
import { Community, Post, User } from '../types';
import confetti from 'canvas-confetti';

interface CommunityDetailViewProps {
  community: Community;
  posts: Post[];
  currentUser: User;
  onBack: () => void;
  onSelectCommunity: (slug: string) => void;
  onOpenProfile: (user: User) => void;
  onToggleJoin: (slug: string) => void;
  onToggleUpvote: (postId: string, delta: 1 | -1) => void;
  onToggleSave: (postId: string) => void;
  onQuickPost: (type: 'post' | 'question' | 'resource' | 'project', title: string, content: string) => void;
  onAddComment: (postId: string, text: string) => void;
}

export const CommunityDetailView: React.FC<CommunityDetailViewProps> = ({
  community,
  posts,
  currentUser,
  onBack,
  onSelectCommunity,
  onOpenProfile,
  onToggleJoin,
  onToggleUpvote,
  onToggleSave,
  onQuickPost,
  onAddComment,
}) => {
  const [activeTab, setActiveTab] = useState<
    'feed' | 'members' | 'resources' | 'problems' | 'projects' | 'opportunities' | 'about'
  >('feed');
  const [feedFilter, setFeedFilter] = useState<'latest' | 'top' | 'unanswered' | 'projects'>('latest');

  // Quick composer state
  const [composerOpen, setComposerOpen] = useState(false);
  const [composerType, setComposerType] = useState<'post' | 'question' | 'resource' | 'project'>('post');
  const [composerTitle, setComposerTitle] = useState('');
  const [composerContent, setComposerContent] = useState('');

  // Bell alert state
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);

  // Inline comment state
  const [expandedCommentsPostId, setExpandedCommentsPostId] = useState<string | null>(null);
  const [commentInputText, setCommentInputText] = useState<{ [postId: string]: string }>({});

  const communityPosts = posts.filter((p) => p.communitySlug === community.slug);

  const handlePostSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (composerTitle.trim()) {
      onQuickPost(composerType, composerTitle.trim(), composerContent.trim());
      setComposerTitle('');
      setComposerContent('');
      setComposerOpen(false);
      confetti({ particleCount: 35, spread: 60 });
    }
  };

  const handleCommentSubmit = (postId: string) => {
    const text = commentInputText[postId]?.trim();
    if (text) {
      onAddComment(postId, text);
      setCommentInputText({ ...commentInputText, [postId]: '' });
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-4 pb-28 space-y-5">
      {/* Top back navigation */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 text-xs font-bold text-slate-600 hover:text-indigo-600 transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to communities</span>
        </button>
      </div>

      {/* 1. Community Header Banner */}
      <div className="bg-gradient-to-r from-emerald-950/90 via-teal-900 to-slate-900 text-white rounded-3xl p-6 shadow-md relative overflow-hidden">
        {/* Subtle background glow */}
        <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="relative z-10 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3.5">
              <div className="w-13 h-13 rounded-2xl bg-emerald-500/20 border border-emerald-400/30 flex items-center justify-center font-mono font-bold text-lg text-emerald-300 shadow-inner">
                {community.slug.slice(0, 2)}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white font-mono">
                    {community.slug}
                  </h1>
                  <span className="text-xs text-emerald-300/80 font-medium flex items-center gap-1 bg-white/10 px-2 py-0.5 rounded-full">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                    {community.membersCount.toLocaleString()} students
                  </span>
                </div>
                <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-xl">
                  {community.description}
                </p>
              </div>
            </div>

            {/* Actions: Joined & Bell */}
            <div className="flex items-center gap-2.5 shrink-0 self-start sm:self-auto">
              <button
                onClick={() => {
                  onToggleJoin(community.slug);
                  if (!community.isJoined) confetti({ particleCount: 30, spread: 50 });
                }}
                className={`px-5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  community.isJoined
                    ? 'bg-white/20 hover:bg-white/30 text-white border border-white/30 backdrop-blur-sm'
                    : 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-lg shadow-indigo-600/30'
                }`}
              >
                {community.isJoined ? 'Joined ✓' : 'Join Community'}
              </button>

              <button
                onClick={() => setNotificationsEnabled(!notificationsEnabled)}
                className={`p-2 rounded-xl border transition-colors cursor-pointer ${
                  notificationsEnabled
                    ? 'bg-white/10 border-white/20 text-white hover:bg-white/20'
                    : 'bg-transparent border-white/10 text-white/50'
                }`}
                title="Community Notifications"
              >
                <Bell className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Members Avatar Overlap */}
          <div className="flex items-center gap-2 pt-1 border-t border-white/10">
            <div className="flex -space-x-2 overflow-hidden">
              <img
                className="inline-block h-6 w-6 rounded-full ring-2 ring-emerald-950 object-cover"
                src={currentUser.avatar}
                alt=""
              />
              <img
                className="inline-block h-6 w-6 rounded-full ring-2 ring-emerald-950 object-cover"
                src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&auto=format&fit=crop&q=80"
                alt=""
              />
              <img
                className="inline-block h-6 w-6 rounded-full ring-2 ring-emerald-950 object-cover"
                src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&auto=format&fit=crop&q=80"
                alt=""
              />
              <img
                className="inline-block h-6 w-6 rounded-full ring-2 ring-emerald-950 object-cover"
                src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&auto=format&fit=crop&q=80"
                alt=""
              />
            </div>
            <span className="text-[11px] text-slate-300 font-medium">+99 students online now</span>
          </div>
        </div>
      </div>

      {/* 2. Community Navigation Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar border-b border-slate-200 pb-1">
        {(
          [
            { id: 'feed', label: 'Feed' },
            { id: 'members', label: 'Members' },
            { id: 'resources', label: 'Resources' },
            { id: 'problems', label: 'Problems' },
            { id: 'projects', label: 'Projects' },
            { id: 'opportunities', label: 'Opportunities' },
            { id: 'about', label: 'About' },
          ] as const
        ).map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-4 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
              activeTab === tab.id
                ? 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Main Grid: Feed & Sidebar */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Feed & Composer */}
        <div className="lg:col-span-2 space-y-4">
          {/* Quick Composer */}
          <div className="bg-white rounded-2xl border border-slate-200/80 p-3.5 shadow-xs space-y-3">
            <div className="flex items-center gap-3">
              <img
                src={currentUser.avatar}
                alt={currentUser.name}
                className="w-9 h-9 rounded-full object-cover ring-1 ring-slate-100"
              />
              <input
                type="text"
                onClick={() => setComposerOpen(true)}
                value={composerTitle}
                onChange={(e) => setComposerTitle(e.target.value)}
                placeholder="Write something in this community..."
                className="w-full text-xs bg-slate-50 hover:bg-slate-100/80 px-4 py-2.5 rounded-xl border border-slate-200 text-slate-800 placeholder-slate-400 focus:outline-none focus:bg-white focus:border-indigo-400 transition-colors cursor-pointer"
              />
            </div>

            {/* Quick type shortcuts */}
            <div className="flex items-center gap-2 pt-1 border-t border-slate-100 overflow-x-auto no-scrollbar">
              <button
                onClick={() => {
                  setComposerType('post');
                  setComposerOpen(true);
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-600 hover:bg-blue-50 hover:text-blue-600 transition-colors cursor-pointer"
              >
                <span>📝</span> Post
              </button>
              <button
                onClick={() => {
                  setComposerType('question');
                  setComposerOpen(true);
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-600 hover:bg-emerald-50 hover:text-emerald-600 transition-colors cursor-pointer"
              >
                <span>❓</span> Question
              </button>
              <button
                onClick={() => {
                  setComposerType('resource');
                  setComposerOpen(true);
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-600 hover:bg-amber-50 hover:text-amber-600 transition-colors cursor-pointer"
              >
                <span>📚</span> Resource
              </button>
              <button
                onClick={() => {
                  setComposerType('project');
                  setComposerOpen(true);
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-600 hover:bg-purple-50 hover:text-purple-600 transition-colors cursor-pointer"
              >
                <span>💻</span> Project
              </button>
            </div>

            {/* Expanded Composer Dialog */}
            {composerOpen && (
              <form onSubmit={handlePostSubmit} className="pt-2 border-t border-slate-100 space-y-3">
                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-bold text-slate-500 uppercase">Type:</span>
                  {(['post', 'question', 'resource', 'project'] as const).map((t) => (
                    <button
                      key={t}
                      type="button"
                      onClick={() => setComposerType(t)}
                      className={`px-2.5 py-0.5 rounded-full text-xs font-semibold capitalize ${
                        composerType === t
                          ? 'bg-indigo-600 text-white'
                          : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      {t}
                    </button>
                  ))}
                </div>

                <textarea
                  value={composerContent}
                  onChange={(e) => setComposerContent(e.target.value)}
                  placeholder="Share details, problem description, GitHub repo link, or doubt..."
                  rows={3}
                  className="w-full text-xs bg-slate-50 p-3 rounded-xl border border-slate-200 text-slate-800 placeholder-slate-400 focus:bg-white focus:border-indigo-400 focus:outline-none"
                />

                <div className="flex items-center justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setComposerOpen(false)}
                    className="px-3 py-1.5 text-xs font-semibold text-slate-500 hover:bg-slate-100 rounded-lg"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={!composerTitle.trim()}
                    className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-40 text-white text-xs font-bold rounded-lg shadow-sm cursor-pointer"
                  >
                    Publish to {community.slug}
                  </button>
                </div>
              </form>
            )}
          </div>

          {/* Feed Filter Bar */}
          <div className="flex items-center justify-between pt-1">
            <div className="flex items-center gap-1.5">
              {(
                [
                  { id: 'latest', label: 'Latest' },
                  { id: 'top', label: 'Top' },
                  { id: 'unanswered', label: 'Unanswered' },
                  { id: 'projects', label: 'Projects' },
                ] as const
              ).map((f) => (
                <button
                  key={f.id}
                  onClick={() => setFeedFilter(f.id)}
                  className={`px-3 py-1 text-xs font-semibold rounded-full transition-all cursor-pointer ${
                    feedFilter === f.id
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>

            <button className="flex items-center gap-1 text-xs font-semibold text-slate-500 hover:text-slate-800 bg-white border border-slate-200 px-2.5 py-1 rounded-lg">
              <SlidersHorizontal className="w-3.5 h-3.5" />
              <span>Filters</span>
            </button>
          </div>

          {/* Posts List */}
          <div className="space-y-4">
            {communityPosts.map((post) => {
              const isCommentsOpen = expandedCommentsPostId === post.id;
              return (
                <div
                  key={post.id}
                  className="bg-white rounded-2xl border border-slate-200/80 p-4 sm:p-5 shadow-xs space-y-3.5"
                >
                  {/* Author Header */}
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <img
                        src={post.author.avatar}
                        alt={post.author.name}
                        onClick={() => onOpenProfile(post.author)}
                        className="w-10 h-10 rounded-full object-cover cursor-pointer hover:opacity-90 ring-1 ring-slate-100"
                      />
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span
                            onClick={() => onOpenProfile(post.author)}
                            className="text-xs sm:text-sm font-bold text-slate-900 hover:text-indigo-600 cursor-pointer"
                          >
                            {post.author.name}
                          </span>
                          <span className="text-[11px] text-slate-400">·</span>
                          <span className="text-[11px] font-medium text-slate-500">
                            {post.author.college} · {post.author.branch}
                          </span>
                          <span className="text-[11px] text-slate-400">·</span>
                          <span className="text-[11px] text-slate-400">{post.timestamp}</span>
                        </div>
                      </div>
                    </div>

                    {/* Badge */}
                    <div className="shrink-0 flex items-center gap-2">
                      {post.type === 'question' && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-100">
                          ? Question
                        </span>
                      )}
                      {post.type === 'post' && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-blue-50 text-blue-700 border border-blue-100">
                          📝 Post
                        </span>
                      )}
                      {post.type === 'project' && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-purple-50 text-purple-700 border border-purple-100">
                          💻 Project
                        </span>
                      )}
                      <button className="text-slate-400 hover:text-slate-600 p-1">
                        <MoreVertical className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Body */}
                  <div className="space-y-2">
                    <h3 className="text-sm sm:text-base font-bold text-slate-900 leading-snug">
                      {post.title}
                    </h3>
                    <p className="text-xs sm:text-sm text-slate-600 leading-relaxed whitespace-pre-line">
                      {post.content}
                    </p>

                    {/* Tag Pills */}
                    {post.tags && post.tags.length > 0 && (
                      <div className="flex flex-wrap gap-1.5 pt-1">
                        {post.tags.map((t) => (
                          <span
                            key={t}
                            className="px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-100"
                          >
                            {t}
                          </span>
                        ))}
                      </div>
                    )}

                    {/* PDF Attachment preview */}
                    {post.attachment && (
                      <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-200">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-lg bg-rose-100 text-rose-700 flex items-center justify-center font-bold text-xs">
                            <FileText className="w-4 h-4" />
                          </div>
                          <div>
                            <p className="text-xs font-bold text-slate-800">
                              {post.attachment.name}
                            </p>
                            <p className="text-[10px] text-slate-500">{post.attachment.size}</p>
                          </div>
                        </div>
                        <button
                          onClick={() => confetti({ particleCount: 20, spread: 40 })}
                          className="text-xs font-bold text-indigo-600 hover:underline cursor-pointer"
                        >
                          Download
                        </button>
                      </div>
                    )}

                    {/* GitHub Repo preview */}
                    {post.githubRepo && (
                      <a
                        href={`https://${post.githubRepo}`}
                        target="_blank"
                        rel="noreferrer"
                        className="flex items-center gap-2.5 p-3 rounded-xl bg-slate-900 text-white hover:bg-slate-800 transition-colors block"
                      >
                        <Github className="w-4 h-4 text-emerald-400" />
                        <div>
                          <p className="text-xs font-mono font-semibold">{post.githubRepo}</p>
                          <p className="text-[10px] text-slate-400">GitHub Repository</p>
                        </div>
                      </a>
                    )}
                  </div>

                  {/* Actions footer */}
                  <div className="flex items-center justify-between pt-2 border-t border-slate-100">
                    <div className="flex items-center gap-4">
                      {/* Upvote Pill */}
                      <button
                        onClick={() => onToggleUpvote(post.id, 1)}
                        className={`flex items-center gap-1 text-xs font-bold transition-colors cursor-pointer ${
                          post.userVote === 1
                            ? 'text-indigo-600'
                            : 'text-slate-500 hover:text-indigo-600'
                        }`}
                      >
                        <ArrowUp className="w-4 h-4" />
                        <span>{post.upvotes}</span>
                      </button>

                      {/* Comments */}
                      <button
                        onClick={() =>
                          setExpandedCommentsPostId(isCommentsOpen ? null : post.id)
                        }
                        className="flex items-center gap-1 text-xs font-semibold text-slate-500 hover:text-slate-800 cursor-pointer"
                      >
                        <MessageSquare className="w-4 h-4" />
                        <span>{post.commentsCount || post.comments.length}</span>
                      </button>

                      {/* Save */}
                      <button
                        onClick={() => onToggleSave(post.id)}
                        className={`flex items-center gap-1 text-xs font-semibold cursor-pointer ${
                          post.saved ? 'text-indigo-600 font-bold' : 'text-slate-500 hover:text-slate-800'
                        }`}
                      >
                        <Bookmark className={`w-4 h-4 ${post.saved ? 'fill-indigo-600' : ''}`} />
                        <span>{post.saved ? 'Saved' : 'Save'}</span>
                      </button>

                      {/* Share */}
                      <button
                        onClick={() => {
                          navigator.clipboard?.writeText(window.location.href);
                          confetti({ particleCount: 15, spread: 35 });
                        }}
                        className="flex items-center gap-1 text-xs font-semibold text-slate-500 hover:text-slate-800 cursor-pointer"
                      >
                        <Share2 className="w-4 h-4" />
                        <span>Share</span>
                      </button>
                    </div>
                  </div>

                  {/* Comments Section */}
                  {isCommentsOpen && (
                    <div className="pt-3 border-t border-slate-100 space-y-3">
                      <div className="space-y-2">
                        {post.comments.map((comment) => (
                          <div key={comment.id} className="flex gap-2.5 p-2 rounded-xl bg-slate-50">
                            <img
                              src={comment.author.avatar}
                              alt={comment.author.name}
                              onClick={() => onOpenProfile(comment.author)}
                              className="w-7 h-7 rounded-full object-cover cursor-pointer"
                            />
                            <div className="flex-1">
                              <div className="flex items-center justify-between">
                                <span
                                  onClick={() => onOpenProfile(comment.author)}
                                  className="text-xs font-bold text-slate-800 cursor-pointer hover:underline"
                                >
                                  {comment.author.name}
                                </span>
                                <span className="text-[10px] text-slate-400">
                                  {comment.timestamp}
                                </span>
                              </div>
                              <p className="text-xs text-slate-600 mt-0.5">{comment.content}</p>
                            </div>
                          </div>
                        ))}
                      </div>

                      {/* Reply input */}
                      <div className="flex items-center gap-2 pt-1">
                        <img
                          src={currentUser.avatar}
                          alt={currentUser.name}
                          className="w-7 h-7 rounded-full object-cover"
                        />
                        <input
                          type="text"
                          value={commentInputText[post.id] || ''}
                          onChange={(e) =>
                            setCommentInputText({
                              ...commentInputText,
                              [post.id]: e.target.value,
                            })
                          }
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') handleCommentSubmit(post.id);
                          }}
                          placeholder="Write a helpful answer..."
                          className="flex-1 px-3 py-1.5 text-xs bg-slate-100 rounded-full border border-transparent focus:bg-white focus:border-indigo-400 focus:outline-none"
                        />
                        <button
                          onClick={() => handleCommentSubmit(post.id)}
                          disabled={!commentInputText[post.id]?.trim()}
                          className="p-1.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-40 text-white rounded-full cursor-pointer"
                        >
                          <Send className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Right 1 Col: Community Meta & Sidebar */}
        <div className="space-y-4">
          {/* About /slug Card */}
          <div className="bg-white rounded-2xl border border-slate-200/80 p-4 space-y-3 shadow-xs">
            <h3 className="text-xs font-bold text-slate-900">About {community.slug}</h3>
            <p className="text-xs text-slate-600 leading-relaxed">{community.description}</p>
            <div className="space-y-1.5 pt-2 border-t border-slate-100 text-xs text-slate-500">
              <div className="flex items-center gap-2">
                <Users className="w-3.5 h-3.5 text-slate-400" />
                <span>{community.membersCount.toLocaleString()} Members</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                <span>Online {community.onlineCount}</span>
              </div>
              <div className="flex items-center gap-2">
                <Sparkles className="w-3.5 h-3.5 text-slate-400" />
                <span>Created on {community.createdDate || '12 Mar 2023'}</span>
              </div>
            </div>
          </div>

          {/* Rules Card */}
          <div className="bg-white rounded-2xl border border-slate-200/80 p-4 space-y-3 shadow-xs">
            <h3 className="text-xs font-bold text-slate-900">Rules</h3>
            <ol className="space-y-2 text-xs text-slate-600 list-decimal list-inside leading-snug">
              {community.rules ? (
                community.rules.map((rule, idx) => <li key={idx}>{rule}</li>)
              ) : (
                <>
                  <li>Be respectful and kind</li>
                  <li>No spam or self-promotion</li>
                  <li>Search before posting</li>
                  <li>Use proper tags</li>
                </>
              )}
            </ol>
            <button className="text-xs font-bold text-indigo-600 hover:underline pt-1 inline-block">
              View all rules →
            </button>
          </div>

          {/* Top Contributors Card */}
          {community.topContributors && community.topContributors.length > 0 && (
            <div className="bg-white rounded-2xl border border-slate-200/80 p-4 space-y-3 shadow-xs">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold text-slate-900">Top Contributors</h3>
                <span className="text-[10px] font-semibold text-slate-400">All-time</span>
              </div>
              <div className="space-y-2.5">
                {community.topContributors.map((tc, idx) => (
                  <div
                    key={tc.user.id}
                    onClick={() => onOpenProfile(tc.user)}
                    className="flex items-center justify-between p-1.5 rounded-xl hover:bg-slate-50 cursor-pointer transition-colors"
                  >
                    <div className="flex items-center gap-2.5">
                      <img
                        src={tc.user.avatar}
                        alt={tc.user.name}
                        className="w-7 h-7 rounded-full object-cover"
                      />
                      <div>
                        <p className="text-xs font-bold text-slate-800">{tc.user.name}</p>
                        <p className="text-[10px] text-slate-400">{tc.points} points</p>
                      </div>
                    </div>
                    <span className="text-sm">
                      {tc.badge === 'gold' ? '🥇' : tc.badge === 'silver' ? '🥈' : '🥉'}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Related Communities Card */}
          <div className="bg-white rounded-2xl border border-slate-200/80 p-4 space-y-3 shadow-xs">
            <h3 className="text-xs font-bold text-slate-900">Related Communities</h3>
            <div className="space-y-2.5">
              {(
                [
                  { slug: '/cp', name: 'Competitive Programming', members: '8.7K' },
                  { slug: '/ai-ml', name: 'AI & Machine Learning', members: '9.8K' },
                  { slug: '/web-dev', name: 'Web Development', members: '6.1K' },
                ] as const
              ).map((rel) => (
                <div
                  key={rel.slug}
                  onClick={() => onSelectCommunity(rel.slug)}
                  className="flex items-center justify-between p-2 rounded-xl hover:bg-slate-50 cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-2.5">
                    <span className="w-7 h-7 rounded-lg bg-indigo-50 text-indigo-600 font-mono font-bold text-xs flex items-center justify-center">
                      {rel.slug.slice(1, 3)}
                    </span>
                    <div>
                      <p className="text-xs font-bold text-slate-800">{rel.slug}</p>
                      <p className="text-[10px] text-slate-400">{rel.members} members</p>
                    </div>
                  </div>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onToggleJoin(rel.slug);
                    }}
                    className="px-2.5 py-1 text-[11px] font-bold text-indigo-600 bg-indigo-50 hover:bg-indigo-100 rounded-lg"
                  >
                    Join
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
