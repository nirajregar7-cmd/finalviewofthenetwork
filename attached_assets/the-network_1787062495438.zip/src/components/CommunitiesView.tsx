import React, { useState } from 'react';
import {
  Plus,
  ArrowUp,
  ArrowDown,
  MessageSquare,
  Bookmark,
  Share2,
  MoreVertical,
  LayoutGrid,
  List,
  Check,
  ChevronRight,
  Sparkles,
  Code,
  Brain,
  Book,
  Rocket,
  Building
} from 'lucide-react';
import { Community, Post, User } from '../types';
import confetti from 'canvas-confetti';

interface CommunitiesViewProps {
  communities: Community[];
  posts: Post[];
  currentUser: User;
  onSelectCommunity: (slug: string) => void;
  onOpenCreate: () => void;
  onOpenProfile: (user: User) => void;
  onToggleJoinCommunity: (slug: string) => void;
  onToggleUpvote: (postId: string, delta: 1 | -1) => void;
  onToggleSave: (postId: string) => void;
}

export const CommunitiesView: React.FC<CommunitiesViewProps> = ({
  communities,
  posts,
  currentUser,
  onSelectCommunity,
  onOpenCreate,
  onOpenProfile,
  onToggleJoinCommunity,
  onToggleUpvote,
  onToggleSave,
}) => {
  const [activeCategory, setActiveCategory] = useState<'all' | 'my' | 'college' | 'interest' | 'career'>('all');
  const [viewMode, setViewMode] = useState<'list' | 'grid'>('list');
  const [sortBy, setSortBy] = useState<'popular' | 'members' | 'recent'>('popular');
  const [trendingCommunityFilter, setTrendingCommunityFilter] = useState<string>('for_you');

  // Filtered communities
  const filteredCommunities = communities.filter((c) => {
    if (activeCategory === 'my') return c.isJoined;
    if (activeCategory === 'college') return c.category === 'college';
    if (activeCategory === 'interest') return c.category === 'interest';
    if (activeCategory === 'career') return c.category === 'career';
    return true;
  });

  // Filtered trending posts
  const trendingPosts = posts.filter((p) => {
    if (trendingCommunityFilter === 'for_you') return true;
    return p.communitySlug === trendingCommunityFilter;
  });

  const getCommunityIcon = (slug: string) => {
    if (slug === '/dsa') return <Code className="w-5 h-5" />;
    if (slug === '/ai-ml') return <Brain className="w-5 h-5" />;
    if (slug === '/gate') return <Book className="w-5 h-5" />;
    if (slug === '/hackathons' || slug === '/startups') return <Rocket className="w-5 h-5" />;
    return <Building className="w-5 h-5" />;
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-8 py-6 pb-28 space-y-7">
      {/* 1. Header & Create Community Button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight">Communities</h1>
          <p className="text-xs sm:text-sm text-slate-500 font-medium">
            Join communities around your interests, college and goals.
          </p>
        </div>
        <button
          onClick={onOpenCreate}
          id="create-community-top-button"
          className="inline-flex items-center justify-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 active:scale-[0.98] text-white text-xs font-bold rounded-full shadow-sm transition-all cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Create Community</span>
        </button>
      </div>

      {/* 2. Category Filter Pills */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-0.5">
        {(
          [
            { id: 'all', label: 'All', icon: '⊞' },
            { id: 'my', label: 'My Communities', icon: '👥' },
            { id: 'college', label: 'College', icon: '🏛️' },
            { id: 'interest', label: 'Interests', icon: '🤍' },
            { id: 'career', label: 'Career', icon: '💼' },
          ] as const
        ).map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveCategory(tab.id)}
            className={`flex items-center gap-1.5 px-4 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all cursor-pointer border ${
              activeCategory === tab.id
                ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
            }`}
          >
            <span>{tab.icon}</span>
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* 3. Most Popular Communities (Cards Slider/Grid) */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-sm sm:text-base font-bold text-slate-900 tracking-tight">
            Most popular communities
          </h2>
          <button
            onClick={() => setActiveCategory('all')}
            className="text-xs font-semibold text-indigo-600 hover:text-indigo-700 cursor-pointer"
          >
            See all
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 overflow-x-auto no-scrollbar">
          {communities.slice(0, 5).map((comm) => (
            <div
              key={comm.id}
              className="bg-white rounded-2xl border border-slate-200/80 p-3.5 flex flex-col justify-between space-y-3 hover:border-indigo-300 hover:shadow-sm transition-all group"
            >
              <div
                onClick={() => onSelectCommunity(comm.slug)}
                className="space-y-2 cursor-pointer"
              >
                <div
                  className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold text-sm ${comm.iconBg}`}
                >
                  {getCommunityIcon(comm.slug)}
                </div>
                <div>
                  <h3 className="text-xs font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">
                    {comm.slug}
                  </h3>
                  <p className="text-[10px] text-slate-500 line-clamp-2 mt-0.5 leading-tight">
                    {comm.displayName}
                  </p>
                </div>
                <p className="text-[10px] font-medium text-slate-400">
                  {(comm.membersCount / 1000).toFixed(1)}K members
                </p>
              </div>

              {/* Joined / Join Button */}
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onToggleJoinCommunity(comm.slug);
                  if (!comm.isJoined) {
                    confetti({ particleCount: 30, spread: 50 });
                  }
                }}
                className={`w-full py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  comm.isJoined
                    ? 'bg-slate-100 text-indigo-700 hover:bg-slate-200 border border-slate-200'
                    : 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-xs'
                }`}
              >
                {comm.isJoined ? 'Joined' : 'Join'}
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* 4. All Communities List */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-sm sm:text-base font-bold text-slate-900 tracking-tight">
            All communities
          </h2>
          <div className="flex items-center gap-2">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="text-xs font-medium text-slate-600 bg-white border border-slate-200 rounded-lg px-2 py-1 focus:outline-none focus:ring-1 focus:ring-indigo-400"
            >
              <option value="popular">Sort by: Popular</option>
              <option value="members">Sort by: Members</option>
              <option value="recent">Sort by: Active</option>
            </select>
            <div className="flex items-center border border-slate-200 rounded-lg bg-white p-0.5">
              <button
                onClick={() => setViewMode('list')}
                className={`p-1 rounded ${viewMode === 'list' ? 'bg-slate-100 text-indigo-600' : 'text-slate-400'}`}
              >
                <List className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => setViewMode('grid')}
                className={`p-1 rounded ${viewMode === 'grid' ? 'bg-slate-100 text-indigo-600' : 'text-slate-400'}`}
              >
                <LayoutGrid className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

        <div className={viewMode === 'list' ? 'space-y-2' : 'grid grid-cols-1 sm:grid-cols-2 gap-3'}>
          {filteredCommunities.map((comm) => (
            <div
              key={comm.id}
              onClick={() => onSelectCommunity(comm.slug)}
              className="bg-white rounded-2xl border border-slate-200/80 p-3.5 flex items-center justify-between gap-3 hover:border-indigo-300 hover:shadow-xs transition-all cursor-pointer group"
            >
              <div className="flex items-center gap-3 min-w-0">
                <div
                  className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${comm.iconBg}`}
                >
                  {getCommunityIcon(comm.slug)}
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs sm:text-sm font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">
                      {comm.slug}
                    </span>
                    {comm.membersCount > 7000 && (
                      <span className="px-1.5 py-0.2 rounded-full text-[9px] font-bold bg-indigo-50 text-indigo-600 border border-indigo-100">
                        Popular
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-500 truncate leading-tight mt-0.5">
                    {comm.description}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3 shrink-0">
                <div className="text-right hidden sm:block">
                  <p className="text-xs font-semibold text-slate-700">
                    {(comm.membersCount / 1000).toFixed(1)}K members
                  </p>
                  <p className="text-[10px] text-slate-400 flex items-center justify-end gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                    {comm.onlineCount} online
                  </p>
                </div>

                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onToggleJoinCommunity(comm.slug);
                  }}
                  className={`px-4 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    comm.isJoined
                      ? 'bg-slate-100 text-indigo-700 hover:bg-slate-200 border border-slate-200'
                      : 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-xs'
                  }`}
                >
                  {comm.isJoined ? 'Joined' : 'Join'}
                </button>

                <button
                  onClick={(e) => {
                    e.stopPropagation();
                  }}
                  className="text-slate-400 hover:text-slate-600 p-1"
                >
                  <MoreVertical className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 5. Trending in Your Communities (Reddit Style Post Feed) */}
      <section className="space-y-3 pt-2">
        <div className="flex items-center justify-between">
          <h2 className="text-sm sm:text-base font-bold text-slate-900 tracking-tight">
            Trending in your communities
          </h2>
          <button
            onClick={() => setTrendingCommunityFilter('for_you')}
            className="text-xs font-semibold text-indigo-600 hover:text-indigo-700 cursor-pointer"
          >
            See all
          </button>
        </div>

        {/* Sub-Filter pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
          {[
            { id: 'for_you', label: 'For you' },
            { id: '/dsa', label: '/dsa' },
            { id: '/ai-ml', label: '/ai-ml' },
            { id: '/nit-trichy', label: '/nit-trichy' },
            { id: '/gate', label: '/gate' },
          ].map((pill) => (
            <button
              key={pill.id}
              onClick={() => setTrendingCommunityFilter(pill.id)}
              className={`px-3 py-1 rounded-full text-xs font-semibold transition-all cursor-pointer ${
                trendingCommunityFilter === pill.id
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              {pill.label}
            </button>
          ))}
        </div>

        {/* Reddit-Style Posts */}
        <div className="space-y-3">
          {trendingPosts.map((post) => (
            <div
              key={post.id}
              className="bg-white rounded-2xl border border-slate-200/80 p-4 shadow-[0_1px_3px_rgba(0,0,0,0.02)] flex gap-3.5 transition-all hover:border-slate-300"
            >
              {/* Upvote Column */}
              <div className="flex flex-col items-center justify-start bg-slate-50 rounded-xl p-1.5 border border-slate-200/60 shrink-0 h-fit">
                <button
                  onClick={() => onToggleUpvote(post.id, 1)}
                  className={`p-1 rounded hover:bg-slate-200/80 transition-colors cursor-pointer ${
                    post.userVote === 1 ? 'text-indigo-600 font-bold' : 'text-slate-400 hover:text-slate-700'
                  }`}
                  title="Upvote"
                >
                  <ArrowUp className="w-4 h-4" />
                </button>
                <span
                  className={`text-xs font-bold my-0.5 ${
                    post.userVote === 1
                      ? 'text-indigo-600'
                      : post.userVote === -1
                      ? 'text-rose-600'
                      : 'text-slate-700'
                  }`}
                >
                  {post.upvotes}
                </span>
                <button
                  onClick={() => onToggleUpvote(post.id, -1)}
                  className={`p-1 rounded hover:bg-slate-200/80 transition-colors cursor-pointer ${
                    post.userVote === -1 ? 'text-rose-600 font-bold' : 'text-slate-400 hover:text-slate-700'
                  }`}
                  title="Downvote"
                >
                  <ArrowDown className="w-4 h-4" />
                </button>
              </div>

              {/* Content Column */}
              <div className="flex-1 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-xs text-slate-500">
                    <button
                      onClick={() => onSelectCommunity(post.communitySlug)}
                      className="font-bold text-indigo-600 hover:underline cursor-pointer"
                    >
                      {post.communitySlug}
                    </button>
                    <span>·</span>
                    <span>{post.timestamp}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    {/* Multi-avatar stack for commenters */}
                    <div className="flex -space-x-1.5 overflow-hidden">
                      <img
                        className="inline-block h-5 w-5 rounded-full ring-2 ring-white object-cover"
                        src={post.author.avatar}
                        alt=""
                      />
                      {post.comments.slice(0, 2).map((c) => (
                        <img
                          key={c.id}
                          className="inline-block h-5 w-5 rounded-full ring-2 ring-white object-cover"
                          src={c.author.avatar}
                          alt=""
                        />
                      ))}
                    </div>
                    <button className="text-slate-400 hover:text-slate-600 p-0.5">
                      <MoreVertical className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <div
                  onClick={() => onSelectCommunity(post.communitySlug)}
                  className="cursor-pointer group"
                >
                  <h3 className="text-xs sm:text-sm font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">
                    {post.title}
                  </h3>
                  <p className="text-xs text-slate-500 line-clamp-2 mt-0.5 leading-relaxed">
                    {post.content}
                  </p>
                </div>

                {/* Footer buttons */}
                <div className="flex items-center gap-4 pt-1 text-xs text-slate-500 font-medium">
                  <button
                    onClick={() => onSelectCommunity(post.communitySlug)}
                    className="flex items-center gap-1 hover:text-slate-800 cursor-pointer"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    <span>{post.commentsCount || post.comments.length} comments</span>
                  </button>
                  <button
                    onClick={() => onToggleSave(post.id)}
                    className={`flex items-center gap-1 hover:text-slate-800 cursor-pointer ${
                      post.saved ? 'text-indigo-600 font-bold' : ''
                    }`}
                  >
                    <Bookmark className={`w-3.5 h-3.5 ${post.saved ? 'fill-indigo-600' : ''}`} />
                    <span>{post.saved ? 'Saved' : 'Save'}</span>
                  </button>
                  <button
                    onClick={() => {
                      navigator.clipboard?.writeText(window.location.href);
                      confetti({ particleCount: 15, spread: 35 });
                    }}
                    className="flex items-center gap-1 hover:text-slate-800 cursor-pointer"
                  >
                    <Share2 className="w-3.5 h-3.5" />
                    <span>Share</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
