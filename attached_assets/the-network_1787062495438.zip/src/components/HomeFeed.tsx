import React, { useState } from 'react';
import {
  Heart,
  MessageSquare,
  Share2,
  Bookmark,
  MoreVertical,
  Plus,
  ArrowRight,
  Sparkles,
  Trophy,
  Users,
  Clock,
  Send,
  Building,
  CheckCircle2,
  FileText,
  Github,
  Award
} from 'lucide-react';
import { Community, Opportunity, Post, User, NavTab } from '../types';
import confetti from 'canvas-confetti';

interface HomeFeedProps {
  currentUser: User;
  posts: Post[];
  opportunities: Opportunity[];
  communities: Community[];
  onSelectCommunity: (slug: string) => void;
  onSelectTab: (tab: NavTab) => void;
  onOpenProfile: (user: User) => void;
  onOpenOpportunity: (opp: Opportunity) => void;
  onToggleUpvote: (postId: string) => void;
  onToggleLike: (postId: string) => void;
  onToggleSave: (postId: string) => void;
  onAddComment: (postId: string, commentText: string) => void;
}

export const HomeFeed: React.FC<HomeFeedProps> = ({
  currentUser,
  posts,
  opportunities,
  communities,
  onSelectCommunity,
  onSelectTab,
  onOpenProfile,
  onOpenOpportunity,
  onToggleUpvote,
  onToggleLike,
  onToggleSave,
  onAddComment,
}) => {
  // Goal filters
  const [goals, setGoals] = useState<string[]>(['GATE', 'AI/ML', 'Placements', 'Startups']);
  const [selectedGoal, setSelectedGoal] = useState<string>('AI/ML');
  const [showAddGoalInput, setShowAddGoalInput] = useState(false);
  const [newGoalText, setNewGoalText] = useState('');

  // Feed tabs
  const [feedFilter, setFeedFilter] = useState<'latest' | 'popular' | 'college' | 'communities'>('latest');

  // Inline comment state
  const [expandedCommentsPostId, setExpandedCommentsPostId] = useState<string | null>(null);
  const [commentInputText, setCommentInputText] = useState<{ [postId: string]: string }>({});

  const handleAddGoal = (e: React.FormEvent) => {
    e.preventDefault();
    if (newGoalText.trim() && !goals.includes(newGoalText.trim())) {
      setGoals([...goals, newGoalText.trim()]);
      setSelectedGoal(newGoalText.trim());
      setNewGoalText('');
      setShowAddGoalInput(false);
      confetti({ particleCount: 40, spread: 60, origin: { y: 0.3 } });
    }
  };

  const handlePostCommentSubmit = (postId: string) => {
    const text = commentInputText[postId]?.trim();
    if (text) {
      onAddComment(postId, text);
      setCommentInputText({ ...commentInputText, [postId]: '' });
    }
  };

  // Filter posts
  const filteredPosts = posts.filter((p) => {
    if (feedFilter === 'college') {
      return (
        p.author.college.toLowerCase().includes(currentUser.college.toLowerCase()) ||
        p.communitySlug.includes('nit-trichy')
      );
    }
    if (feedFilter === 'communities') {
      return currentUser.communities.includes(p.communitySlug);
    }
    if (feedFilter === 'popular') {
      return p.upvotes > 30 || (p.likesCount || 0) > 30;
    }
    return true;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-8 py-6 pb-24 space-y-8">
      {/* 1. Greeting & Goal Selection */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
              Good evening, Niraj <span className="animate-bounce">👋</span>
            </h1>
            <p className="text-xs sm:text-sm text-slate-500 font-medium">
              What are you working toward today?
            </p>
          </div>
        </div>

        {/* Goal Chips */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
          {goals.map((g) => {
            const isSelected = selectedGoal === g;
            let icon = '🎯';
            if (g === 'AI/ML') icon = '🧠';
            if (g === 'Placements') icon = '💼';
            if (g === 'Startups') icon = '🚀';
            return (
              <button
                key={g}
                onClick={() => setSelectedGoal(g)}
                className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all duration-200 cursor-pointer border ${
                  isSelected
                    ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm shadow-indigo-200 ring-2 ring-indigo-100'
                    : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                }`}
              >
                <span>{icon}</span>
                <span>{g}</span>
              </button>
            );
          })}

          {showAddGoalInput ? (
            <form onSubmit={handleAddGoal} className="flex items-center gap-1">
              <input
                type="text"
                autoFocus
                value={newGoalText}
                onChange={(e) => setNewGoalText(e.target.value)}
                placeholder="e.g. UPSC, DSA"
                className="px-2.5 py-1 text-xs rounded-full border border-indigo-300 focus:outline-none focus:ring-1 focus:ring-indigo-500 bg-white"
              />
              <button
                type="submit"
                className="px-2 py-1 text-xs bg-indigo-600 text-white rounded-full font-bold hover:bg-indigo-700"
              >
                Add
              </button>
              <button
                type="button"
                onClick={() => setShowAddGoalInput(false)}
                className="text-xs text-slate-400 hover:text-slate-600 px-1"
              >
                ✕
              </button>
            </form>
          ) : (
            <button
              onClick={() => setShowAddGoalInput(true)}
              className="flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-medium text-indigo-600 bg-indigo-50/70 hover:bg-indigo-100/70 border border-indigo-100 whitespace-nowrap transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add goal</span>
            </button>
          )}
        </div>
      </section>

      {/* 2. Main Two-Column Layout on Desktop */}
      <div className="flex flex-col xl:flex-row gap-8 items-start">
        {/* Main Feed Column */}
        <div className="flex-1 min-w-0 space-y-6 w-full">
          {/* For You Today (Cards Grid/Carousel) */}
          <section className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-sm sm:text-base font-bold text-slate-900 tracking-tight">
            For you today
          </h2>
          <button
            onClick={() => onSelectTab('learn')}
            className="text-xs font-semibold text-indigo-600 hover:text-indigo-700 cursor-pointer"
          >
            See all
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {/* Card 1: GATE Preparation */}
          <div
            onClick={() => onSelectTab('learn')}
            className="bg-emerald-50/50 hover:bg-emerald-50/80 border border-emerald-100/80 rounded-2xl p-3.5 flex flex-col justify-between transition-all hover:shadow-sm cursor-pointer group"
          >
            <div className="space-y-2">
              <div className="w-8 h-8 rounded-xl bg-emerald-100 flex items-center justify-center text-emerald-700 text-sm">
                🎓
              </div>
              <div>
                <h3 className="text-xs font-bold text-slate-800 group-hover:text-emerald-700 transition-colors">
                  GATE Preparation
                </h3>
                <p className="text-[11px] text-slate-500 mt-0.5 leading-tight">
                  12 resources · 84 students learning
                </p>
              </div>
            </div>
            <div className="mt-3 flex items-center text-[11px] font-bold text-emerald-600 group-hover:translate-x-0.5 transition-transform">
              Continue <ArrowRight className="w-3 h-3 ml-1" />
            </div>
          </div>

          {/* Card 2: AI & ML Hackathon */}
          <div
            onClick={() => onOpenOpportunity(opportunities[0])}
            className="bg-indigo-50/50 hover:bg-indigo-50/80 border border-indigo-100/80 rounded-2xl p-3.5 flex flex-col justify-between transition-all hover:shadow-sm cursor-pointer group"
          >
            <div className="space-y-2">
              <div className="w-8 h-8 rounded-xl bg-indigo-100 flex items-center justify-center text-indigo-700 text-sm">
                🚀
              </div>
              <div>
                <h3 className="text-xs font-bold text-slate-800 group-hover:text-indigo-700 transition-colors">
                  AI & ML Hackathon
                </h3>
                <p className="text-[11px] text-slate-500 mt-0.5 leading-tight">
                  Registration closes in 3 days
                </p>
              </div>
            </div>
            <div className="mt-3 flex items-center text-[11px] font-bold text-indigo-600 group-hover:translate-x-0.5 transition-transform">
              Apply now <ArrowRight className="w-3 h-3 ml-1" />
            </div>
          </div>

          {/* Card 3: AI & ML Community */}
          <div
            onClick={() => onSelectCommunity('/ai-ml')}
            className="bg-blue-50/50 hover:bg-blue-50/80 border border-blue-100/80 rounded-2xl p-3.5 flex flex-col justify-between transition-all hover:shadow-sm cursor-pointer group"
          >
            <div className="space-y-2">
              <div className="w-8 h-8 rounded-xl bg-blue-100 flex items-center justify-center text-blue-700 text-sm">
                👥
              </div>
              <div>
                <h3 className="text-xs font-bold text-slate-800 group-hover:text-blue-700 transition-colors">
                  AI & ML Community
                </h3>
                <p className="text-[11px] text-slate-500 mt-0.5 leading-tight">
                  1,240 students active
                </p>
              </div>
            </div>
            <div className="mt-3 flex items-center text-[11px] font-bold text-blue-600 group-hover:translate-x-0.5 transition-transform">
              Join <ArrowRight className="w-3 h-3 ml-1" />
            </div>
          </div>

          {/* Card 4: Find a DSA Study Partner */}
          <div
            onClick={() => onSelectTab('connect')}
            className="bg-amber-50/50 hover:bg-amber-50/80 border border-amber-100/80 rounded-2xl p-3.5 flex flex-col justify-between transition-all hover:shadow-sm cursor-pointer group"
          >
            <div className="space-y-2">
              <div className="w-8 h-8 rounded-xl bg-amber-100 flex items-center justify-center text-amber-700 text-sm">
                🤝
              </div>
              <div>
                <h3 className="text-xs font-bold text-slate-800 group-hover:text-amber-700 transition-colors">
                  Find a DSA Study Partner
                </h3>
                <p className="text-[11px] text-slate-500 mt-0.5 leading-tight">
                  18 students looking
                </p>
              </div>
            </div>
            <div className="mt-3 flex items-center text-[11px] font-bold text-amber-600 group-hover:translate-x-0.5 transition-transform">
              Explore <ArrowRight className="w-3 h-3 ml-1" />
            </div>
          </div>
        </div>
      </section>

      {/* 3. Opportunities For You */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-sm sm:text-base font-bold text-slate-900 tracking-tight">
            Opportunities for you
          </h2>
          <button
            onClick={() => onSelectTab('communities')}
            className="text-xs font-semibold text-indigo-600 hover:text-indigo-700 cursor-pointer"
          >
            See all
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
          {/* Opp 1: Inter-IIT Hack Series */}
          <div className="bg-white rounded-2xl border border-slate-200/80 p-4 shadow-[0_2px_8px_rgba(0,0,0,0.02)] flex flex-col justify-between space-y-3 hover:border-indigo-200 transition-all">
            <div className="space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-purple-50 text-purple-700 border border-purple-100">
                  Hackathon
                </span>
                <span className="text-[11px] font-medium text-slate-400 flex items-center gap-1">
                  <Clock className="w-3 h-3" /> 4 days left
                </span>
              </div>
              <div className="flex gap-3 items-start">
                <div className="flex-1">
                  <h3 className="text-xs font-bold text-slate-900 leading-tight">
                    Inter-IIT Hack Series
                  </h3>
                  <p className="text-[11px] text-slate-500 mt-0.5">ML / Web / Hardware</p>
                  <p className="text-[11px] font-semibold text-indigo-700 mt-1">₹2L prize pool</p>
                  <p className="text-[10px] text-slate-400">Teams of 4</p>
                </div>
                <img
                  src="https://images.unsplash.com/photo-1541339907198-e08756dedf3f?w=100&auto=format&fit=crop&q=80"
                  alt="IIT Madras"
                  className="w-12 h-12 rounded-xl object-cover ring-1 ring-slate-100 shrink-0"
                />
              </div>
            </div>
            <button
              onClick={() => onOpenOpportunity(opportunities[0])}
              className="w-full py-2 bg-indigo-600 hover:bg-indigo-700 active:scale-[0.98] text-white text-xs font-bold rounded-xl transition-all shadow-xs cursor-pointer"
            >
              Apply
            </button>
          </div>

          {/* Opp 2: ML Research Intern */}
          <div className="bg-white rounded-2xl border border-slate-200/80 p-4 shadow-[0_2px_8px_rgba(0,0,0,0.02)] flex flex-col justify-between space-y-3 hover:border-emerald-200 transition-all">
            <div className="space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-100">
                  Internship
                </span>
                <span className="text-[11px] font-medium text-slate-400 flex items-center gap-1">
                  <Clock className="w-3 h-3" /> 6 days left
                </span>
              </div>
              <div className="flex gap-3 items-start">
                <div className="flex-1">
                  <h3 className="text-xs font-bold text-slate-900 leading-tight">
                    ML Research Intern
                  </h3>
                  <p className="text-[11px] text-slate-500 mt-0.5">Python · Machine Learning</p>
                  <p className="text-[11px] font-semibold text-emerald-700 mt-1">Stipend ₹25k/month</p>
                  <p className="text-[10px] text-slate-400">Remote</p>
                </div>
                <img
                  src="https://images.unsplash.com/photo-1562774053-701939374585?w=100&auto=format&fit=crop&q=80"
                  alt="IISc Campus"
                  className="w-12 h-12 rounded-xl object-cover ring-1 ring-slate-100 shrink-0"
                />
              </div>
            </div>
            <button
              onClick={() => onOpenOpportunity(opportunities[1])}
              className="w-full py-2 bg-emerald-600 hover:bg-emerald-700 active:scale-[0.98] text-white text-xs font-bold rounded-xl transition-all shadow-xs cursor-pointer"
            >
              Apply
            </button>
          </div>

          {/* Opp 3: National Case Challenge */}
          <div className="bg-white rounded-2xl border border-slate-200/80 p-4 shadow-[0_2px_8px_rgba(0,0,0,0.02)] flex flex-col justify-between space-y-3 hover:border-amber-200 transition-all">
            <div className="space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-50 text-amber-700 border border-amber-100">
                  Competition
                </span>
                <span className="text-[11px] font-medium text-slate-400 flex items-center gap-1">
                  <Clock className="w-3 h-3" /> 10 days left
                </span>
              </div>
              <div className="flex gap-3 items-start">
                <div className="flex-1">
                  <h3 className="text-xs font-bold text-slate-900 leading-tight">
                    National Case Challenge
                  </h3>
                  <p className="text-[11px] text-slate-500 mt-0.5">Open to all colleges</p>
                  <p className="text-[11px] font-semibold text-amber-700 mt-1">Win exciting prizes</p>
                  <p className="text-[10px] text-slate-400">Online</p>
                </div>
                <div className="w-12 h-12 rounded-xl bg-amber-50 border border-amber-200 flex items-center justify-center shrink-0">
                  <Trophy className="w-6 h-6 text-amber-600" />
                </div>
              </div>
            </div>
            <button
              onClick={() => onOpenOpportunity(opportunities[2])}
              className="w-full py-2 bg-amber-600 hover:bg-amber-700 active:scale-[0.98] text-white text-xs font-bold rounded-xl transition-all shadow-xs cursor-pointer"
            >
              Apply
            </button>
          </div>
        </div>
      </section>

      {/* 4. Your Communities (Horizontal Pills) */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-sm sm:text-base font-bold text-slate-900 tracking-tight">
            Your communities
          </h2>
          <button
            onClick={() => onSelectTab('communities')}
            className="text-xs font-semibold text-indigo-600 hover:text-indigo-700 cursor-pointer"
          >
            See all
          </button>
        </div>

        <div className="flex items-center gap-2.5 overflow-x-auto no-scrollbar py-1">
          {communities.map((comm) => (
            <div
              key={comm.id}
              onClick={() => onSelectCommunity(comm.slug)}
              className="flex items-center gap-2.5 px-3.5 py-2 rounded-2xl bg-white border border-slate-200 hover:border-indigo-300 hover:shadow-xs transition-all cursor-pointer shrink-0 group"
            >
              <div
                className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold ${comm.iconBg}`}
              >
                {comm.slug.slice(1, 3).toUpperCase()}
              </div>
              <div>
                <p className="text-xs font-bold text-slate-800 group-hover:text-indigo-600 transition-colors">
                  {comm.slug}
                </p>
                <p className="text-[10px] text-slate-400">
                  {(comm.membersCount / 1000).toFixed(1)}K students
                </p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 5. What's Happening (Feed Posts) */}
      <section className="space-y-4 pt-1">
        <div className="flex items-center justify-between border-b border-slate-200 pb-2">
          <h2 className="text-sm sm:text-base font-bold text-slate-900 tracking-tight">
            What's happening
          </h2>

          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
            {(
              [
                { id: 'latest', label: 'Latest' },
                { id: 'popular', label: 'Popular' },
                { id: 'college', label: 'My College' },
                { id: 'communities', label: 'My Communities' },
              ] as const
            ).map((tab) => (
              <button
                key={tab.id}
                onClick={() => setFeedFilter(tab.id)}
                className={`px-3 py-1 text-xs font-semibold rounded-full transition-all cursor-pointer ${
                  feedFilter === tab.id
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Post Items */}
        <div className="space-y-3.5">
          {filteredPosts.map((post) => {
            const isCommentsOpen = expandedCommentsPostId === post.id;
            return (
              <article
                key={post.id}
                className="bg-white rounded-2xl border border-slate-200/80 p-4 sm:p-5 shadow-[0_1px_4px_rgba(0,0,0,0.02)] space-y-3 transition-all hover:border-slate-300"
              >
                {/* Author row */}
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <img
                      src={post.author.avatar}
                      alt={post.author.name}
                      onClick={() => onOpenProfile(post.author)}
                      className="w-10 h-10 rounded-full object-cover ring-1 ring-slate-100 cursor-pointer hover:opacity-90"
                    />
                    <div>
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span
                          onClick={() => onOpenProfile(post.author)}
                          className="text-xs sm:text-sm font-bold text-slate-900 hover:text-indigo-600 cursor-pointer"
                        >
                          {post.author.name}
                        </span>
                        {post.author.verified && (
                          <span className="inline-flex items-center gap-0.5 text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-1.5 py-0.2 rounded-full border border-emerald-200">
                            ✓ Verified
                          </span>
                        )}
                        <span className="text-[11px] text-slate-400">·</span>
                        <span className="text-[11px] font-medium text-slate-600">
                          {post.author.college}
                        </span>
                        <span className="text-[11px] text-slate-400">·</span>
                        <span className="text-[11px] text-slate-400">{post.timestamp}</span>
                      </div>
                      <button
                        onClick={() => onSelectCommunity(post.communitySlug)}
                        className="text-[11px] font-semibold text-indigo-600 hover:underline inline-block mt-0.5 cursor-pointer"
                      >
                        {post.communitySlug}
                      </button>
                    </div>
                  </div>

                  {/* Post Type Badge */}
                  <div className="shrink-0 flex items-center gap-2">
                    {post.type === 'hackathon' && (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-indigo-50 text-indigo-700 border border-indigo-100">
                        🚀 Hackathon
                      </span>
                    )}
                    {post.type === 'question' && (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-100">
                        ? Question
                      </span>
                    )}
                    {post.type === 'project' && (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-purple-50 text-purple-700 border border-purple-100">
                        💻 Project
                      </span>
                    )}
                    {post.type === 'post' && (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-blue-50 text-blue-700 border border-blue-100">
                        📝 Post
                      </span>
                    )}
                    <button className="text-slate-400 hover:text-slate-600 p-1" title="More options">
                      <MoreVertical className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Post Content */}
                <div className="space-y-2">
                  <h3 className="text-sm sm:text-base font-bold text-slate-900 leading-snug">
                    {post.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-600 leading-relaxed whitespace-pre-line">
                    {post.content}
                  </p>

                  {/* Special tags for Hackathon posts */}
                  {post.prizePool && (
                    <div className="flex flex-wrap gap-2 pt-1">
                      {post.prizePool && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl text-xs font-semibold bg-purple-50 text-purple-700 border border-purple-200">
                          🏆 {post.prizePool}
                        </span>
                      )}
                      {post.teamSize && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-200">
                          👥 {post.teamSize}
                        </span>
                      )}
                      {post.deadline && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl text-xs font-semibold bg-rose-50 text-rose-700 border border-rose-200">
                          ⏰ {post.deadline}
                        </span>
                      )}
                    </div>
                  )}

                  {/* PDF Attachment preview */}
                  {post.attachment && (
                    <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-200 hover:bg-slate-100/70 transition-colors">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg bg-rose-100 text-rose-700 flex items-center justify-center font-bold text-xs">
                          <FileText className="w-4 h-4" />
                        </div>
                        <div>
                          <p className="text-xs font-bold text-slate-800">{post.attachment.name}</p>
                          <p className="text-[10px] text-slate-500">{post.attachment.size}</p>
                        </div>
                      </div>
                      <span className="text-xs font-bold text-indigo-600 hover:underline cursor-pointer">
                        Download PDF
                      </span>
                    </div>
                  )}

                  {/* GitHub Repo preview */}
                  {post.githubRepo && (
                    <a
                      href={`https://${post.githubRepo}`}
                      target="_blank"
                      rel="noreferrer"
                      className="flex items-center gap-2.5 p-3 rounded-xl bg-slate-900 text-white hover:bg-slate-800 transition-colors block"
                    >
                      <Github className="w-4 h-4 text-emerald-400" />
                      <div>
                        <p className="text-xs font-mono font-semibold">{post.githubRepo}</p>
                        <p className="text-[10px] text-slate-400">View code repository & visualizer</p>
                      </div>
                    </a>
                  )}
                </div>

                {/* Footer Interaction Bar */}
                <div className="flex items-center justify-between pt-2 border-t border-slate-100">
                  <div className="flex items-center gap-4">
                    {/* Like / Heart Button */}
                    <button
                      onClick={() => onToggleLike(post.id)}
                      className={`flex items-center gap-1.5 text-xs font-bold transition-colors cursor-pointer ${
                        post.liked ? 'text-rose-600' : 'text-slate-500 hover:text-rose-600'
                      }`}
                    >
                      <Heart
                        className={`w-4 h-4 ${post.liked ? 'fill-rose-600 text-rose-600' : ''}`}
                      />
                      <span>{post.likesCount || post.upvotes}</span>
                    </button>

                    {/* Comments Button */}
                    <button
                      onClick={() =>
                        setExpandedCommentsPostId(isCommentsOpen ? null : post.id)
                      }
                      className="flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
                    >
                      <MessageSquare className="w-4 h-4" />
                      <span>{post.commentsCount || post.comments.length}</span>
                    </button>

                    {/* Share Button */}
                    <button
                      onClick={() => {
                        navigator.clipboard?.writeText(window.location.href);
                        confetti({ particleCount: 20, spread: 40 });
                      }}
                      className="flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
                    >
                      <Share2 className="w-4 h-4" />
                      <span>Share</span>
                    </button>
                  </div>

                  {/* Bookmark Button */}
                  <button
                    onClick={() => onToggleSave(post.id)}
                    className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                      post.saved ? 'text-indigo-600 bg-indigo-50' : 'text-slate-400 hover:text-slate-700'
                    }`}
                    title={post.saved ? 'Saved' : 'Save post'}
                  >
                    <Bookmark className={`w-4 h-4 ${post.saved ? 'fill-indigo-600' : ''}`} />
                  </button>
                </div>

                {/* Inline Expanded Comments */}
                {isCommentsOpen && (
                  <div className="pt-3 border-t border-slate-100 space-y-3 animate-in fade-in duration-200">
                    <div className="space-y-2">
                      {post.comments.length > 0 ? (
                        post.comments.map((comment) => (
                          <div key={comment.id} className="flex gap-2.5 p-2 rounded-xl bg-slate-50/80">
                            <img
                              src={comment.author.avatar}
                              alt={comment.author.name}
                              onClick={() => onOpenProfile(comment.author)}
                              className="w-7 h-7 rounded-full object-cover cursor-pointer"
                            />
                            <div className="flex-1">
                              <div className="flex items-center justify-between">
                                <span
                                  onClick={() => onOpenProfile(comment.author)}
                                  className="text-xs font-bold text-slate-800 cursor-pointer hover:underline"
                                >
                                  {comment.author.name}
                                </span>
                                <span className="text-[10px] text-slate-400">
                                  {comment.timestamp}
                                </span>
                              </div>
                              <p className="text-xs text-slate-600 mt-0.5">{comment.content}</p>
                            </div>
                          </div>
                        ))
                      ) : (
                        <p className="text-xs text-slate-400 py-1 text-center">
                          No comments yet. Be the first to start the discussion!
                        </p>
                      )}
                    </div>

                    {/* Add comment input */}
                    <div className="flex items-center gap-2 pt-1">
                      <img
                        src={currentUser.avatar}
                        alt={currentUser.name}
                        className="w-7 h-7 rounded-full object-cover"
                      />
                      <input
                        type="text"
                        value={commentInputText[post.id] || ''}
                        onChange={(e) =>
                          setCommentInputText({
                            ...commentInputText,
                            [post.id]: e.target.value,
                          })
                        }
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') handlePostCommentSubmit(post.id);
                        }}
                        placeholder="Write a helpful reply..."
                        className="flex-1 px-3 py-1.5 text-xs bg-slate-100 rounded-full border border-transparent focus:bg-white focus:border-indigo-400 focus:outline-none"
                      />
                      <button
                        onClick={() => handlePostCommentSubmit(post.id)}
                        disabled={!commentInputText[post.id]?.trim()}
                        className="p-1.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-40 text-white rounded-full transition-all cursor-pointer"
                      >
                        <Send className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                )}
              </article>
            );
          })}
        </div>
      </section>
    </div>

    {/* Right Sleek Widgets Sidebar on Desktop */}
    <aside className="hidden xl:flex flex-col w-80 shrink-0 space-y-6 sticky top-24">
      {/* Widget 1: Deep Indigo Featured Opportunity Card */}
      <div className="bg-indigo-900 text-white p-6 rounded-2xl shadow-xl space-y-4 relative overflow-hidden">
        <div className="absolute -right-8 -bottom-8 w-32 h-32 bg-indigo-800/40 rounded-full blur-2xl pointer-events-none"></div>
        <div className="flex items-center justify-between">
          <span className="text-[10px] font-extrabold uppercase tracking-widest text-indigo-300">
            Featured Opportunity
          </span>
          <span className="px-2 py-0.5 rounded-full bg-indigo-800 text-indigo-200 text-[10px] font-bold">
            Inter-IIT Hack
          </span>
        </div>
        <div>
          <h3 className="text-base font-black leading-snug">
            Inter-IIT Hack Series 2025
          </h3>
          <p className="text-xs text-indigo-200 mt-1 leading-relaxed">
            National hackathon for ML, Hardware, and Web. ₹2L prize pool with fast-track interviews.
          </p>
        </div>
        <div className="flex items-center justify-between text-xs font-semibold text-indigo-200 pt-1">
          <span>🏆 ₹2,00,000</span>
          <span>⏰ 4 days left</span>
        </div>
        <button
          onClick={() => onOpenOpportunity(opportunities[0])}
          className="w-full py-2.5 bg-white text-indigo-900 font-bold rounded-xl text-xs hover:bg-indigo-50 transition-all shadow-md active:scale-98 cursor-pointer"
        >
          Apply Now →
        </button>
      </div>

      {/* Widget 2: Trending Communities */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4 shadow-xs">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
            Trending Communities
          </h3>
          <button
            onClick={() => onSelectTab('communities')}
            className="text-xs font-semibold text-indigo-600 hover:text-indigo-700 cursor-pointer"
          >
            View all
          </button>
        </div>
        <div className="space-y-3">
          {communities.slice(0, 4).map((comm, idx) => (
            <div
              key={comm.id}
              onClick={() => onSelectCommunity(comm.slug)}
              className="flex items-center justify-between p-2 rounded-xl hover:bg-slate-50 transition-colors cursor-pointer group"
            >
              <div className="flex items-center gap-2.5">
                <span className="text-xs font-bold text-slate-400 w-4">#{idx + 1}</span>
                <div>
                  <p className="text-xs font-bold text-slate-800 group-hover:text-indigo-600 transition-colors">
                    {comm.slug}
                  </p>
                  <p className="text-[10px] text-slate-400">
                    {(comm.membersCount / 1000).toFixed(1)}k members
                  </p>
                </div>
              </div>
              <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-100">
                +{Math.floor(comm.membersCount / 30)} today
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Widget 3: Active Mentors */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-3 shadow-xs">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
            Verified Mentors
          </h3>
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
        </div>
        <div className="flex -space-x-2 overflow-hidden py-1">
          <img
            className="inline-block h-8 w-8 rounded-full ring-2 ring-white object-cover"
            src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80"
            alt="Mentor 1"
          />
          <img
            className="inline-block h-8 w-8 rounded-full ring-2 ring-white object-cover"
            src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&auto=format&fit=crop&q=80"
            alt="Mentor 2"
          />
          <img
            className="inline-block h-8 w-8 rounded-full ring-2 ring-white object-cover"
            src="https://images.unsplash.com/photo-1517841905240-472988babdf9?w=100&auto=format&fit=crop&q=80"
            alt="Mentor 3"
          />
          <div className="h-8 w-8 rounded-full bg-indigo-50 border-2 border-white flex items-center justify-center text-[10px] font-bold text-indigo-600">
            +42
          </div>
        </div>
        <p className="text-xs text-slate-500 leading-relaxed">
          Connect with senior students & alumni from top IITs, NITs, and IIITs for career guidance.
        </p>
        <button
          onClick={() => onSelectTab('connect')}
          className="w-full py-2 bg-slate-50 hover:bg-slate-100 text-slate-700 font-bold text-xs rounded-xl border border-slate-200 transition-colors cursor-pointer"
        >
          Browse Mentors
        </button>
      </div>
    </aside>
  </div>
</div>
);
};
