import React, { useState } from 'react';
import { NavTab, User, Community, Post, Opportunity, LearningTopic, ChatConversation, NotificationItem } from './types';
import {
  CURRENT_USER,
  MOCK_USERS,
  MOCK_COMMUNITIES,
  MOCK_POSTS,
  MOCK_OPPORTUNITIES,
  MOCK_LEARNING_TOPIC,
  MOCK_CHATS,
  MOCK_NOTIFICATIONS,
} from './data/mockData';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { BottomNav } from './components/BottomNav';
import { HomeFeed } from './components/HomeFeed';
import { CommunitiesView } from './components/CommunitiesView';
import { CommunityDetailView } from './components/CommunityDetailView';
import { ConnectView } from './components/ConnectView';
import { LearnView } from './components/LearnView';
import { ChatsView } from './components/ChatsView';
import { ProfileModal } from './components/ProfileModal';
import { OpportunityDetailModal } from './components/OpportunityDetailModal';
import { CreatePostModal } from './components/CreatePostModal';
import { RecommendRoadmapModal } from './components/RecommendRoadmapModal';
import { BookMentorModal } from './components/BookMentorModal';
import { Plus } from 'lucide-react';

export const App: React.FC = () => {
  // Navigation & View States
  const [activeTab, setActiveTab] = useState<NavTab>('home');
  const [selectedCommunitySlug, setSelectedCommunitySlug] = useState<string | null>(null);

  // App Data States
  const [currentUser, setCurrentUser] = useState<User>(CURRENT_USER);
  const [users, setUsers] = useState<Record<string, User>>(MOCK_USERS);
  const [communities, setCommunities] = useState<Community[]>(MOCK_COMMUNITIES);
  const [posts, setPosts] = useState<Post[]>(MOCK_POSTS);
  const [opportunities, setOpportunities] = useState<Opportunity[]>(MOCK_OPPORTUNITIES);
  const [learningTopic, setLearningTopic] = useState<LearningTopic>(MOCK_LEARNING_TOPIC);
  const [conversations, setConversations] = useState<ChatConversation[]>(MOCK_CHATS);
  const [notifications, setNotifications] = useState<NotificationItem[]>(MOCK_NOTIFICATIONS);

  // Modals & Overlays
  const [activeProfileUser, setActiveProfileUser] = useState<User | null>(null);
  const [activeOpportunity, setActiveOpportunity] = useState<Opportunity | null>(null);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isRecommendModalOpen, setIsRecommendModalOpen] = useState(false);
  const [activeMentorBooking, setActiveMentorBooking] = useState<User | null>(null);

  // Upvote / Downvote
  const handleToggleUpvote = (postId: string, delta: 1 | -1 = 1) => {
    setPosts((prev) =>
      prev.map((p) => {
        if (p.id === postId) {
          const currentVote = p.userVote || 0;
          let newVote = currentVote;
          let newUpvotes = p.upvotes;

          if (currentVote === delta) {
            // Cancel vote
            newVote = 0;
            newUpvotes -= delta;
          } else if (currentVote === 0) {
            // Cast new vote
            newVote = delta;
            newUpvotes += delta;
          } else {
            // Switch from +1 to -1 or vice versa
            newVote = delta;
            newUpvotes += delta * 2;
          }
          return { ...p, upvotes: newUpvotes, userVote: newVote as any };
        }
        return p;
      })
    );
  };

  // Like / Heart Post
  const handleToggleLike = (postId: string) => {
    setPosts((prev) =>
      prev.map((p) => {
        if (p.id === postId) {
          const liked = !p.liked;
          const likesCount = (p.likesCount || p.upvotes) + (liked ? 1 : -1);
          return { ...p, liked, likesCount };
        }
        return p;
      })
    );
  };

  // Bookmark / Save Post
  const handleToggleSave = (postId: string) => {
    setPosts((prev) =>
      prev.map((p) => {
        if (p.id === postId) {
          return { ...p, saved: !p.saved };
        }
        return p;
      })
    );
  };

  // Add Comment
  const handleAddComment = (postId: string, text: string) => {
    const newComment = {
      id: `comm-${Date.now()}`,
      author: currentUser,
      content: text,
      timestamp: 'Just now',
      upvotes: 1,
    };
    setPosts((prev) =>
      prev.map((p) => {
        if (p.id === postId) {
          return {
            ...p,
            comments: [newComment, ...p.comments],
            commentsCount: (p.commentsCount || p.comments.length) + 1,
          };
        }
        return p;
      })
    );
  };

  // Join / Leave Community
  const handleToggleJoinCommunity = (slug: string) => {
    setCommunities((prev) =>
      prev.map((c) => {
        if (c.slug === slug) {
          const isJoined = !c.isJoined;
          const membersCount = c.membersCount + (isJoined ? 1 : -1);
          return { ...c, isJoined, membersCount };
        }
        return c;
      })
    );

    // Also update currentUser's community list
    setCurrentUser((prev) => {
      const exists = prev.communities.includes(slug);
      return {
        ...prev,
        communities: exists
          ? prev.communities.filter((s) => s !== slug)
          : [...prev.communities, slug],
      };
    });
  };

  // Connect / Disconnect Student
  const handleToggleConnect = (userId: string) => {
    setUsers((prev) => {
      const target = prev[userId];
      if (!target) return prev;
      return {
        ...prev,
        [userId]: {
          ...target,
          isConnected: !target.isConnected,
        },
      };
    });

    if (activeProfileUser && activeProfileUser.id === userId) {
      setActiveProfileUser((prev) => (prev ? { ...prev, isConnected: !prev.isConnected } : null));
    }
  };

  // Direct chat transition
  const handleStartDirectChat = (targetUser: User) => {
    // Check if conversation exists
    let existing = conversations.find(
      (c) =>
        (c.participant && c.participant.id === targetUser.id) ||
        (c.title && c.title.toLowerCase().includes(targetUser.name.toLowerCase()))
    );

    if (!existing) {
      existing = {
        id: `conv-direct-${Date.now()}`,
        type: 'direct',
        participant: targetUser,
        title: targetUser.name,
        subtitle: `${targetUser.college} · ${targetUser.branch}`,
        avatar: targetUser.avatar,
        lastMessage: 'Started conversation',
        lastMessageTime: 'Just now',
        lastTimestamp: 'Just now',
        unreadCount: 0,
        online: true,
        verified: targetUser.verified,
        messages: [
          {
            id: `msg-${Date.now()}`,
            senderId: targetUser.id,
            senderName: targetUser.name,
            text: `Hi Niraj! Glad to connect with you from ${targetUser.college}!`,
            timestamp: 'Just now',
          },
        ],
      };
      setConversations([existing, ...conversations]);
    }

    setActiveTab('chats');
  };

  // Send message in Chat
  const handleSendMessage = (conversationId: string, text: string) => {
    const newMsg = {
      id: `msg-${Date.now()}`,
      senderId: currentUser.id,
      senderName: currentUser.name,
      text,
      timestamp: 'Just now',
    };

    setConversations((prev) =>
      prev.map((c) => {
        if (c.id === conversationId) {
          return {
            ...c,
            lastMessage: text,
            lastMessageTime: 'Just now',
            lastTimestamp: 'Just now',
            messages: [...c.messages, newMsg],
          };
        }
        return c;
      })
    );
  };

  // Create Post
  const handleCreatePost = (postData: {
    communitySlug: string;
    type: 'post' | 'question' | 'project' | 'hackathon' | 'resource';
    title: string;
    content: string;
    prizePool?: string;
    teamSize?: string;
    deadline?: string;
    tags: string[];
    fileName?: string;
  }) => {
    const newPost: Post = {
      id: `post-${Date.now()}`,
      communitySlug: postData.communitySlug,
      communityName: postData.communitySlug,
      author: currentUser,
      type: postData.type as any,
      title: postData.title,
      content: postData.content,
      timestamp: 'Just now',
      upvotes: 1,
      userVote: 1,
      likesCount: 1,
      liked: true,
      commentsCount: 0,
      saved: false,
      prizePool: postData.prizePool,
      teamSize: postData.teamSize,
      deadline: postData.deadline,
      tags: postData.tags,
      attachment: postData.fileName
        ? {
            name: postData.fileName,
            size: '1.4 MB',
            type: 'pdf',
            url: '#',
          }
        : undefined,
      comments: [],
    };

    setPosts([newPost, ...posts]);
  };

  // Create Community
  const handleCreateCommunity = (commData: {
    slug: string;
    displayName: string;
    description: string;
    category: 'college' | 'interest' | 'career';
  }) => {
    const newComm: Community = {
      id: `comm-custom-${Date.now()}`,
      slug: commData.slug,
      name: commData.displayName,
      displayName: commData.displayName,
      description: commData.description,
      membersCount: 1,
      onlineCount: 1,
      category: commData.category,
      isJoined: true,
      iconBg: 'bg-indigo-100 text-indigo-800',
      iconType: 'users',
      createdDate: 'Today',
      rules: ['Be respectful to all peers', 'Share verified notes & resources', 'No spam'],
    };

    setCommunities([newComm, ...communities]);
    setCurrentUser((prev) => ({
      ...prev,
      communities: [...prev.communities, newComm.slug],
    }));
  };

  // Quick navigation helpers
  const handleSelectCommunity = (slug: string) => {
    setSelectedCommunitySlug(slug);
  };

  const handleSelectTab = (tab: NavTab) => {
    setActiveTab(tab);
    setSelectedCommunitySlug(null);
  };

  const currentCommunity = communities.find((c) => c.slug === selectedCommunitySlug);

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-[#0F172A] flex font-sans antialiased selection:bg-indigo-100 selection:text-indigo-900">
      {/* 1. Sleek Glass Sidebar (Desktop) */}
      <Sidebar
        activeTab={activeTab}
        onSelectTab={handleSelectTab}
        currentUser={currentUser}
        communities={communities}
        onSelectCommunity={handleSelectCommunity}
        onOpenProfile={(u) => setActiveProfileUser(u)}
        unreadChatsCount={2}
      />

      {/* 2. Main Content Area */}
      <div className="main-content flex flex-col min-w-0 h-screen overflow-y-auto">
        {/* Top Navigation */}
        <Header
          currentUser={currentUser}
          communities={communities}
          users={users}
          posts={posts}
          notifications={notifications}
          onSelectCommunity={(slug) => {
            setSelectedCommunitySlug(slug);
            setActiveTab('communities');
          }}
          onOpenProfile={(user) => setActiveProfileUser(user)}
          onSelectTab={handleSelectTab}
          onMarkAllNotificationsRead={() => {
            setNotifications((prev) => prev.map((n) => ({ ...n, unread: false })));
          }}
        />

        {/* View Switcher */}
        <main className="flex-1 w-full pb-24 lg:pb-12">
          {selectedCommunitySlug && currentCommunity ? (
            /* Community Detail View */
            <CommunityDetailView
              community={currentCommunity}
              posts={posts}
              currentUser={currentUser}
              onBack={() => setSelectedCommunitySlug(null)}
              onSelectCommunity={handleSelectCommunity}
              onOpenProfile={(u) => setActiveProfileUser(u)}
              onToggleJoin={handleToggleJoinCommunity}
              onToggleUpvote={handleToggleUpvote}
              onToggleSave={handleToggleSave}
              onQuickPost={(type, title, content) =>
                handleCreatePost({
                  communitySlug: currentCommunity.slug,
                  type,
                  title,
                  content,
                  tags: ['Discussion'],
                })
              }
              onAddComment={handleAddComment}
            />
          ) : activeTab === 'home' ? (
            /* Home Feed */
            <HomeFeed
              currentUser={currentUser}
              posts={posts}
              opportunities={opportunities}
              communities={communities}
              onSelectCommunity={handleSelectCommunity}
              onSelectTab={handleSelectTab}
              onOpenProfile={(u) => setActiveProfileUser(u)}
              onOpenOpportunity={(opp) => setActiveOpportunity(opp)}
              onToggleUpvote={(postId) => handleToggleUpvote(postId, 1)}
              onToggleLike={handleToggleLike}
              onToggleSave={handleToggleSave}
              onAddComment={handleAddComment}
            />
          ) : activeTab === 'communities' ? (
            /* Communities Directory */
            <CommunitiesView
              communities={communities}
              posts={posts}
              currentUser={currentUser}
              onSelectCommunity={handleSelectCommunity}
              onOpenCreate={() => setIsCreateModalOpen(true)}
              onOpenProfile={(u) => setActiveProfileUser(u)}
              onToggleJoinCommunity={handleToggleJoinCommunity}
              onToggleUpvote={handleToggleUpvote}
              onToggleSave={handleToggleSave}
            />
          ) : activeTab === 'connect' ? (
            /* Connect / Mentors / Students Directory */
            <ConnectView
              users={users}
              communities={communities}
              currentUser={currentUser}
              onOpenProfile={(u) => setActiveProfileUser(u)}
              onSelectCommunity={handleSelectCommunity}
              onToggleConnect={handleToggleConnect}
              onToggleJoinCommunity={handleToggleJoinCommunity}
              onBookMentor={(mentor) => setActiveMentorBooking(mentor)}
              onStartDirectChat={handleStartDirectChat}
            />
          ) : activeTab === 'learn' ? (
            /* Learn Roadmap View */
            <LearnView
              topic={learningTopic}
              currentUser={currentUser}
              onOpenProfile={(u) => setActiveProfileUser(u)}
              onSelectCommunity={handleSelectCommunity}
              onOpenOpportunity={(opp) => setActiveOpportunity(opp)}
              onOpenRecommendQuiz={() => setIsRecommendModalOpen(true)}
            />
          ) : activeTab === 'chats' ? (
            /* Chats Dashboard */
            <ChatsView
              conversations={conversations}
              currentUser={currentUser}
              onOpenProfile={(u) => setActiveProfileUser(u)}
              onSendMessage={handleSendMessage}
            />
          ) : null}
        </main>
      </div>

      {/* 3. Floating Action Button (FAB) */}
      <button
        onClick={() => setIsCreateModalOpen(true)}
        className="fab fixed bottom-20 lg:bottom-8 right-6 lg:right-8 w-14 h-14 bg-indigo-600 hover:bg-indigo-700 active:scale-95 text-white rounded-full flex items-center justify-center cursor-pointer z-40 transition-all duration-200"
        title="Create a post or community"
        id="sleek-fab-create"
      >
        <Plus className="w-7 h-7 stroke-[2.5]" />
      </button>

      {/* 4. Bottom Sticky Navigation Bar on Mobile */}
      <div className="lg:hidden">
        <BottomNav
          activeTab={activeTab}
          onSelectTab={handleSelectTab}
          onOpenCreate={() => setIsCreateModalOpen(true)}
          unreadChatsCount={2}
        />
      </div>

      {/* 4. Modals and Overlays */}
      {/* Profile Modal (Image 6) */}
      {activeProfileUser && (
        <ProfileModal
          user={activeProfileUser}
          currentUser={currentUser}
          onClose={() => setActiveProfileUser(null)}
          onSelectCommunity={(slug) => {
            setActiveProfileUser(null);
            handleSelectCommunity(slug);
          }}
          onToggleConnect={handleToggleConnect}
          onStartDirectChat={handleStartDirectChat}
          onUpdateCurrentUserProfile={(updated) => {
            setCurrentUser((prev) => ({ ...prev, ...updated }));
          }}
        />
      )}

      {/* Opportunity Detail Modal */}
      {activeOpportunity && (
        <OpportunityDetailModal
          opportunity={activeOpportunity}
          onClose={() => setActiveOpportunity(null)}
        />
      )}

      {/* Create Post / New Community Modal */}
      {isCreateModalOpen && (
        <CreatePostModal
          communities={communities}
          currentUser={currentUser}
          onClose={() => setIsCreateModalOpen(false)}
          onCreatePost={handleCreatePost}
          onCreateCommunity={handleCreateCommunity}
        />
      )}

      {/* Recommend Roadmap Modal */}
      {isRecommendModalOpen && (
        <RecommendRoadmapModal
          onClose={() => setIsRecommendModalOpen(false)}
          onSelectRoadmap={(slug) => {
            setSelectedCommunitySlug(slug);
            setActiveTab('communities');
          }}
        />
      )}

      {/* Book Mentor Modal */}
      {activeMentorBooking && (
        <BookMentorModal
          mentor={activeMentorBooking}
          onClose={() => setActiveMentorBooking(null)}
        />
      )}
    </div>
  );
};

export default App;
