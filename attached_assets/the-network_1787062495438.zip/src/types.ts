export type NavTab = 'home' | 'communities' | 'connect' | 'learn' | 'chats';

export interface UserProject {
  title: string;
  description: string;
  githubLink?: string;
  tags: string[];
}

export interface User {
  id: string;
  name: string;
  avatar: string;
  college: string;
  branch: string;
  year?: string;
  verified: boolean;
  verifiedCollege?: string;
  bio?: string;
  location?: string;
  interests: string[];
  skills: string[];
  communities: string[]; // slugs
  goals?: string[];
  matchScore?: number;
  mutualCommunitiesCount?: number;
  mutualCommunityIcons?: string[];
  connectionsCount?: number;
  projects?: UserProject[];
  stats?: {
    postsCount: number;
    connectionsCount: number;
    points: number;
    rank?: string;
    helpedCount?: number;
    rating?: number;
  };
  mentorInfo?: {
    isMentor: boolean;
    rating: number;
    studentsHelped: number;
    price: string; // "Free" | "₹200/session"
    speciality: string;
    companyOrRole: string;
  };
  availableFor?: {
    hackathons: boolean;
    projects: boolean;
    studyPartner: boolean;
    startup: boolean;
    networking: boolean;
  } | string[];
  isOnline?: boolean;
  isConnected?: boolean;
  connectionPending?: boolean;
}

export interface Community {
  id: string;
  slug: string; // e.g. "/dsa"
  name: string;
  displayName: string;
  iconType?: 'code' | 'brain' | 'book' | 'rocket' | 'building' | 'briefcase' | 'trophy' | 'users';
  iconBg: string;
  iconColor?: string;
  description: string;
  membersCount: number;
  onlineCount: number;
  category: 'interest' | 'college' | 'career';
  isJoined: boolean;
  rules?: string[];
  createdDate?: string;
  topContributors?: {
    user: User;
    points: number;
    badge: 'gold' | 'silver' | 'bronze';
  }[];
  relatedSlugs?: string[];
}

export interface PostComment {
  id: string;
  author: User;
  content: string;
  timestamp: string;
  upvotes: number;
  userVote?: 1 | -1 | null;
}

export interface Post {
  id: string;
  author: User;
  communitySlug: string;
  communityName?: string;
  timestamp: string;
  type: 'post' | 'question' | 'hackathon' | 'project' | 'resource' | 'collab';
  title: string;
  content: string;
  tags?: string[];
  upvotes: number;
  userVote?: 1 | -1 | null;
  commentsCount: number;
  comments: PostComment[];
  saved: boolean;
  liked?: boolean;
  likesCount?: number;
  prizePool?: string;
  teamSize?: string;
  deadline?: string;
  attachment?: {
    name: string;
    size: string;
    type?: string;
    url?: string;
  };
  githubRepo?: string;
  pollData?: {
    question: string;
    options: { id: string; text: string; votes: number }[];
    totalVotes: number;
    userVotedOptionId?: string;
  };
}

export interface Opportunity {
  id: string;
  title: string;
  category: 'Hackathon' | 'Internship' | 'Competition' | 'Scholarship' | 'Research' | 'Campus';
  categoryColor?: string;
  description: string;
  tags: string[];
  prizeOrStipend: string;
  teamSize?: string;
  daysLeft: number;
  deadlineDate?: string;
  imageUrl?: string;
  thumbnail?: string;
  location?: string;
  applyLink?: string;
  isSaved?: boolean;
  collegeRestricted?: string;
  requirements?: string[];
}

export interface RoadmapStep {
  id: string;
  title: string;
  description?: string;
  status: 'completed' | 'in_progress' | 'locked';
  items: {
    id: string;
    title: string;
    status: 'completed' | 'in_progress' | 'not_started';
  }[];
}

export interface LearningTopic {
  id: string;
  slug: string;
  name: string;
  summaryPath: string;
  icon: string;
  category: string;
  progressPercent: number;
  studentsLearningCount: number;
  steps: RoadmapStep[];
  resources: {
    notesCount: number;
    videosCount: number;
    practiceCount: number;
    projectsCount: number;
  };
  opportunities: Opportunity[];
}

export interface ChatMessage {
  id: string;
  chatId?: string;
  senderId: string;
  senderName?: string;
  text: string;
  timestamp: string;
  read?: boolean;
  reactions?: {
    emoji: string;
    count: number;
    users: string[];
  }[];
}

export interface ChatConversation {
  id: string;
  type: 'direct' | 'community' | 'study_group';
  title?: string;
  subtitle?: string;
  avatar?: string;
  online?: boolean;
  verified?: boolean;
  participant?: User;
  communitySlug?: string;
  communityName?: string;
  communityIcon?: string;
  communityIconBg?: string;
  lastMessage: string;
  lastMessageTime?: string;
  lastTimestamp?: string;
  unreadCount: number;
  messages: ChatMessage[];
}

export interface NotificationItem {
  id: string;
  type: 'reply' | 'upvote' | 'connection_request' | 'community' | 'hackathon' | 'mentor' | 'message';
  title: string;
  subtitle: string;
  timestamp: string;
  unread: boolean;
  avatar?: string;
  badgeIcon?: string;
  targetId?: string;
  user?: User;
}
